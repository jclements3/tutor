# HANDOFF — Harp Drill Book Project

This tarball contains a partial first-principles harp drill book for
33-string lever harp, plus the build script that produces a single
self-contained HTML and a print-ready PDF from the markdown source.

It was developed in a session that started from a desire to rebuild the
SATB-to-harp conversion problem from scratch, then converged on a
**drill curriculum** as the foundation that the rest of the project will
build on.

---

## What's in the tarball

```
harp-drill-book/
├── HANDOFF.md           ← you are reading this
├── build_book.py        ← build script (markdown + ABC → HTML/PDF)
└── book/                ← markdown source for the book
    ├── README.md
    ├── 00-preface.md
    ├── 00-notation.md
    ├── 01-single-hand-foundations.md
    ├── 02-zigzag-patterns.md
    ├── 03-linear-arpeggios.md
    ├── 04-two-hand-alternation.md
    ├── 05-block-and-rolled.md
    ├── 06-layered-textures.md
    ├── 07-wide-spread.md
    ├── 08-modifiers.md
    ├── 09-gestures.md
    ├── 10-chord-cycles.md
    ├── appendix-a-voicings.md
    ├── appendix-b-keys.md
    ├── appendix-c-routine.md
    └── appendix-d-index.md
```

17 markdown files. 11 chapters, 4 appendices, plus README and preface.
65 ABC code blocks (one per drill, with a few extra examples in
chapter 10's chord-cycle reference section).

---

## How to build

```bash
# install dependencies (Ubuntu/Debian)
apt-get install abcm2ps wkhtmltopdf

# build both HTML and PDF
python3 build_book.py

# build HTML only (no wkhtmltopdf needed)
python3 build_book.py --html-only

# custom paths
python3 build_book.py --book-dir ./book --out ./my-book.html
```

Output is a single self-contained HTML (~530 KB, all SVG music inlined)
plus an A4 PDF (~640 KB, 55 pages). The HTML has no external file
dependencies — every staff is inlined as SVG.

---

## Project context

### The larger project this fits into

The user (JC) is building a system to convert OpenHymnal SATB ABC files
into idiomatic harp compositions. Previous attempts (`reharm` and
`retab` pipelines, both in the project knowledge) reached working state
but had architectural issues:

- **Reharm** chose chords first, voicings second. Used a 118-fraction
  "Harp Chord System" with strict diatonic discipline.
- **Retab** chose voicings first, textures implicit. Used an 8-voice
  roster (Dr, B, T2, T1, A2, A1, S2, S1, Gl).

Both pipelines work and produce reviewable output (294 hymns rendered),
but they elide the **texture layer** — the choice of *how* the chord is
distributed across time (Alberti, walking, rolled, etc.) — which is the
actual organizing principle of harp arrangement.

This drill book is the first-principles rebuild: it makes the texture
vocabulary explicit, drillable, and trainable.

### What was decided in this session

1. **The seven core pattern families.** Zigzag, linear ascending, linear
   descending, pulse, bass-and-chord, sustained-plus-motion,
   wide-spread, block/rolled. These are *kinds of motion*, not just
   named patterns. Everything else is parameters, modifiers, or
   gestures applied on top.

2. **58 distinct skills** in the core curriculum. (65 ABC blocks in the
   book because chapter 10's chord-cycle reference has additional
   non-drill examples.)

3. **The pedagogical order matters.** Within each chapter, drills are
   ordered simplest-to-hardest by physical demand. Across chapters,
   each new chapter assumes mastery of earlier ones.

4. **Lever-harp constraints.** The book targets a 33-string E♭ lever
   harp, C2–A6 range, no lever changes mid-piece. This is the most
   constrained instrument profile; the drills work on any larger harp
   as a strict superset.

5. **Strictly diatonic.** No accidentals, no modulation. The lever harp
   "no flips" rule is treated as a feature, not a limitation. Within
   one diatonic key, the available material is dense enough for
   thousands of arrangements.

### What this drill book is NOT yet

- It does **not** generate arrangements. The drill book is the *physical
  vocabulary*; an arrangement generator (which would consume this
  vocabulary) is a future layer.
- It does **not** connect to OpenHymnal hymn data. The next step would
  be to take a hymn and *annotate* it with drill-vocabulary choices —
  e.g., "this phrase uses 6.3 (Pedal + Alberti) in F major."
- Some ABC blocks have **engraving quirks** — `abcm2ps` sometimes
  switches between bass and treble clef mid-bar when pitches cross
  staff boundaries. Cosmetic only; the underlying notation is correct.

---

## Known issues to address

1. **Clef switching in some drills.** Drills like 2.2 Murky bass and
   2.5 Inner-bounce engrave with mixed clefs because their pitches
   span the bass staff boundary. Fix: force `K:C clef=bass` in the ABC
   header, or rewrite pitches to stay within one register.

2. **Two-handed drill engraving.** The `%%score (V1) (V2)` directive
   works but the spacing between the two staves isn't always ideal.
   Some two-handed drills (e.g., 3.3 Continuous ascent) render with
   awkward voice ordering.

3. **No audio.** Each drill has prose + engraved notation + a chord
   cycle, but no MIDI reference. Earlier in the session, six MIDI
   drill examples were generated (`drill_1_1_alberti.mid` through
   `drill_6_1_pedal_alberti.mid` in outputs). Extending this to all 58
   drills would give the book audible references alongside the
   notation.

4. **Some appendix-A voicings include sharps that the E♭ lever harp
   cannot produce.** The appendix lists "G major key" through "A major
   key" but those require sharp strings which the E♭-tuned instrument
   doesn't have. Either narrow the appendix to the four achievable
   keys (C, F, B♭, E♭) or split it into "C-base instrument" and
   "E♭-base instrument" sections.

5. **Chapter 10's chord-cycle drills are described but not engraved
   per-pattern.** The book shows the chord cycles abstractly. A
   complete chapter 10 would show, for each (pattern × cycle) pair,
   the engraved realization. That's 8 core patterns × 6 cycles = 48
   additional staves. Significant addition; consider whether it's
   worth the size or whether the abstract description is enough.

---

## Working assumptions

- **The user prefers concise responses.** Long expository answers were
  explicitly flagged as too much. Short, direct, technical responses
  are preferred unless explicitly asked to expand.
- **The user reads on a phone.** Don't bury content in deep
  tree-structures; don't ask multiple-choice questions at the end of
  every message.
- **The user values empirical work over discussion.** Generating
  artifacts (MIDI, PDF, code) is more valued than describing what
  *could* be generated.
- **The user is technically fluent.** No need to explain basic music
  theory, ABC notation, or Python.

---

## Suggested next steps (in priority order)

1. **Fix the clef-switching bug** by adding `clef=bass` to ABC headers
   in drills that need it. ~30 min work.

2. **Generate MIDI for all 58 drills.** Extend the existing
   `build_midi.py` and `build_drills.py` patterns to cover the whole
   curriculum. ~2 hours.

3. **Build a tablet-friendly viewer** that combines the HTML book with
   the MIDI audio so each drill has a "play reference" button. Could
   use `abcjs` for runtime ABC rendering plus HTML5 audio for the
   MIDI files.

4. **Annotate one OpenHymnal hymn** with drill-vocabulary choices.
   Take a single hymn (start with "Blessed Jesus, at Thy Word"), map
   each phrase to a drill ID, and render the resulting arrangement.
   This is the bridge from drill book to actual arrangement.

5. **Build the deployment-layer logic.** Given a phrase's harmonic
   content and position in the verse, automatically select an
   appropriate drill ID. This is the "structural assignment" layer
   from the texture tree.

---

## File conventions

- Markdown headings: `#` for chapter title, `##` for drills, `###` for
  drill-internal sections (rare).
- Drill metadata appears as a series of `**Hand:** ...` bold lines at
  the top of each drill.
- ABC code blocks are fenced with ` ```abc ... ``` `.
- Drill numbering: `<chapter>.<position>`. So 2.1 is the first drill of
  chapter 2.
- Chord cycles use roman numerals in prose, actual chord names
  (`"C"`, `"F"`, etc.) in ABC.

---

## Contact / hand-off

This handoff document and the build script were generated in a Claude
session. If you (the next Claude session) are continuing this work, the
above context plus the source files should be sufficient to extend the
book, fix issues, or integrate it with the larger SATB→harp pipeline.

The drill book is intentionally separable from the rest of the project.
It can be extended, refined, and used on its own as a practice
curriculum. Or it can become the vocabulary layer that an arrangement
generator consumes. Both paths remain open.
