# Appendix D — Index of drills

Complete index of all 58 drills, organized for quick lookup.

---

## By chapter

| Drill | Title | Hand | Meter | Rate |
|---|---|---|---|---|
| **1.1** | Bass pulse | LH | 4/4 | quarter |
| **1.2** | Alternating bass | LH | 4/4 | quarter |
| **1.3** | Stride bass | LH | 4/4 | quarter |
| **2.1** | Alberti — b·t·m·t | LH | 4/4 | eighth |
| **2.2** | Murky bass — b·m·t·m | LH | 4/4 | eighth |
| **2.3** | Reverse Alberti — t·b·m·b | LH | 4/4 | eighth |
| **2.4** | Cascading — t·m·b·m | LH | 4/4 | eighth |
| **2.5** | Inner-bounce — m·t·m·b | LH | 4/4 | eighth |
| **2.6** | Pattern switching | LH | 4/4 | eighth |
| **3.1** | Triple arpeggio | LH | 3/4 | eighth |
| **3.2** | Triple + rest | LH | 4/4 | eighth |
| **3.3** | Continuous ascent | 2H | 4/4 | eighth |
| **3.4** | Sextuplet ascent | LH | 4/4 | sixteenth |
| **3.5** | Octave climb | 2H | 4/4 | sixteenth |
| **3.6** | Reverse triple arpeggio | LH | 3/4 | eighth |
| **3.7** | Reverse + rest | LH | 4/4 | eighth |
| **3.8** | Octave descent | 2H | 4/4 | sixteenth |
| **4.1** | Oom-pah | 2H | 4/4 | quarter |
| **4.2** | Waltz bass | 2H | 3/4 | quarter |
| **4.3** | Slow oom-pah | 2H | 4/4 | half |
| **5.1** | Block chord | 2H | 4/4 | whole |
| **5.2** | Standard rolled chord | 2H | 4/4 | event |
| **5.3** | Slow roll | 2H | 4/4 | event |
| **5.4** | Reverse roll | 2H | 4/4 | event |
| **5.5** | Étouffé block | 2H | 4/4 | quarter |
| **5.6** | Staggered roll | 2H | 4/4 | event |
| **5.7** | Outward roll | 2H | 4/4 | event |
| **5.8** | Inward roll | 2H | 4/4 | event |
| **5.9** | Fast roll (flam) | 2H | 4/4 | event |
| **6.1** | Pedal point under harmony | 2H | 4/4 | mixed |
| **6.2** | Pedal + chord pulse | 2H | 4/4 | mixed |
| **6.3** | Pedal + Alberti | 2H | 4/4 | mixed |
| **6.4** | Pedal + arpeggio | 2H | 4/4 | mixed |
| **7.1** | Wide arpeggio | 2H | 4/4 | eighth |
| **7.2** | Bell tones | 2H | 4/4 | half |
| **7.3** | Cross-hand cascade | 2H cross | 4/4 | eighth |
| **8.1** | Common-tone holdover | LH | 4/4 | eighth |
| **8.2** | Passing tones | LH | 4/4 | eighth |
| **8.3** | Neighbor tones | LH | 4/4 | eighth |
| **8.4** | Anticipations | LH | 4/4 | eighth |
| **8.5** | 4-3 suspension | RH | 4/4 | quarter |
| **8.6** | 9-8 suspension | RH | 4/4 | quarter |
| **8.7** | 7-6 suspension | RH | 4/4 | quarter |
| **8.8** | Anticipated bass | LH | 4/4 | quarter |
| **8.9** | Bell-note accent | LH | 4/4 | eighth |
| **8.10** | Octave doubling pop | LH or RH | 4/4 | eighth |
| **8.11** | Mid-pattern pause | LH | 4/4 | sixteenth |
| **8.12** | Échappée | LH | 4/4 | sixteenth |
| **8.13** | Anticipated cadence note | LH | 4/4 | eighth |
| **9.1** | Standard glissando | 1H | 4/4 | event |
| **9.2** | Slow glissando | 1H | 4/4 | event |
| **9.3** | Partial glissando | 1H | 4/4 | event |
| **9.4** | Two-hand glissando | 2H | 4/4 | event |
| **9.5** | Snap glissando | 1H | 4/4 | event |
| **9.6** | Harmonic note | 1H | 4/4 | whole |
| **9.7** | Two-note harmonic chord | 1H | 4/4 | whole |
| **9.8** | Trill | 1H | 4/4 | sixteenth |
| **9.9** | Two-note tremolo | 1H or 2H | 4/4 | sixteenth |
| **9.10** | Bisbigliando | 2H | 4/4 | sixteenth |

---

## By difficulty (easiest first)

For a student who wants to know where to start when feeling overwhelmed,
this list is roughly ordered by physical difficulty:

1. 1.1 Bass pulse
2. 1.2 Alternating bass
3. 2.1 Alberti
4. 3.1 Triple arpeggio
5. 4.1 Oom-pah
6. 5.1 Block chord
7. 5.2 Standard rolled chord
8. 2.2 Murky bass
9. 2.3 Reverse Alberti
10. 4.2 Waltz bass
11. 2.4 Cascading
12. 3.2 Triple + rest
13. 3.6 Reverse triple
14. 6.1 Pedal point under harmony  *(the conceptual leap)*
15. 6.2 Pedal + chord pulse
16. 5.5 Étouffé block
17. 4.3 Slow oom-pah
18. 1.3 Stride bass
19. 2.5 Inner-bounce
20. 6.3 Pedal + Alberti
21. 2.6 Pattern switching
22. 3.3 Continuous ascent
23. 7.1 Wide arpeggio
24. 5.3 Slow roll
25. 5.4 Reverse roll
26. 5.9 Fast roll
27. 7.2 Bell tones
28. 6.4 Pedal + arpeggio
29. 3.5 Octave climb
30. 3.4 Sextuplet ascent
31. 3.8 Octave descent
32. 5.6 Staggered roll
33. 7.3 Cross-hand cascade
34. 5.7 Outward roll
35. 5.8 Inward roll
36. 8.1–8.13 Modifiers (all ~equally easy if base pattern is solid)
37. 9.1 Standard glissando
38. 9.6 Harmonic note
39. 9.3 Partial glissando
40. 9.7 Two-note harmonic chord
41. 9.2 Slow glissando
42. 9.5 Snap glissando
43. 9.8 Trill
44. 9.9 Two-note tremolo
45. 9.4 Two-hand glissando
46. 9.10 Bisbigliando

---

## By musical use

**For phrase openings:**
5.1 Block chord, 5.2 Standard rolled chord, 5.7 Outward roll

**For continuation phrases:**
2.1 Alberti, 2.2 Murky bass, 3.1 Triple arpeggio, 6.3 Pedal + Alberti

**For climaxes:**
5.6 Staggered roll, 7.1 Wide arpeggio, 9.4 Two-hand glissando

**For cadences:**
5.2 Standard rolled chord, 9.1 Standard glissando, 9.6 Harmonic note

**For waltz / triple-meter pieces:**
3.1 Triple arpeggio, 3.6 Reverse triple, 4.2 Waltz bass

**For gentle/contemplative passages:**
2.3 Reverse Alberti, 6.1 Pedal point, 7.2 Bell tones

**For active/driving passages:**
2.1 Alberti, 4.1 Oom-pah, 5.5 Étouffé block

**For text-painting moments:**
9.6 Harmonic note, 9.10 Bisbigliando, 9.4 Two-hand glissando
