# Notation, fingerings, posture

## ABC notation

Every drill is written in ABC, a plain-text music notation. If you've never
read ABC before, here's the minimum you need.

Notes are letters. Uppercase C is C4 (the C below middle C in this book's
convention is `C,`). Lowercase c is C5 (one octave up). Commas drop an
octave per comma; apostrophes raise an octave each. So:

- `C,,` = C2 (low bass on the lever harp)
- `C,` = C3
- `C` = C4 (middle C)
- `c` = C5
- `c'` = C6

The `K:` header sets the key. `K:C` means C major, no accidentals.
`K:Bb` means B♭ major, two flats. The lever harp's natural set is
listed in [appendix B](appendix-b-keys.md).

The `M:` header sets the meter. `M:4/4` is common time. `M:3/4` is waltz.
`M:6/8` is compound duple.

The `L:` header sets the default note length. `L:1/8` means an unmarked
note is an eighth note. Numbers after a note multiply: `C2` is a half
note (two eighths) when `L:1/8` is set.

Chord labels appear in quotes above notes: `"C"` over the first note of
a bar indicates that bar's chord. The drills use roman numerals in
prose but actual chord names in the ABC, since ABC's chord-symbol field
is the standard way.

## Fingering

The drills assume the standard harp fingering convention:

- **1** = thumb
- **2** = index
- **3** = middle
- **4** = ring

The pinky is not used. Most drills can be played with whichever fingers
fall naturally; where a specific fingering matters, it's noted under the
ABC.

## Hand assignment

Each drill specifies which hand. Most drills are one-handed; the two-hand
drills make clear which hand plays what. By default:

- LH plays the bass register (C2–C4, below middle C)
- RH plays the upper register (C4–A6, middle C and above)

The "octave above middle C" range (C4–C5) is shared territory — either
hand can reach there comfortably.

## Posture

Sit at the harp with the soundboard against your right shoulder (for a
right-handed instrument). The neck of the harp should rest just above
your right collarbone. Both hands curve over the strings from above; the
fingers approach the strings from outside, plucking toward the palm.

Wrists stay relaxed and slightly arched. Elbows hang naturally — neither
clamped against the ribs nor wing-stretched outward. Shoulders down.

Re-check posture every few minutes during practice. Most playing
problems trace back to posture before they trace back to technique.

## A note on tempos

Tempos in this book are *practice targets*, not performance speeds. Start
each drill at half the listed tempo. When you can play it cleanly and
evenly at half tempo, raise to two-thirds. When that's clean, raise to
the listed tempo. Then push past it — the listed tempo is a milestone,
not a ceiling.

A drill is mastered when you can play it at the listed tempo with
**even velocity across all notes**, **no fingering hesitation**, and
**no audible pattern boundary** between bars. The chord changes
underneath the pattern; the pattern itself never breaks.
