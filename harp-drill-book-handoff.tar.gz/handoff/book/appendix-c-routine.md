# Appendix C — Recommended practice routine

This appendix lays out a realistic practice schedule for working through the
drill book over roughly 9–12 months at 30–60 minutes per day.

The schedule below assumes you can practice 5–6 days per week. Adjust the
timeline if your practice frequency is less.

---

## Daily structure (30–45 minutes)

A good session structure for any phase:

| Time | Activity |
|------|---|
| 5 min | Warm-up (any mastered drill from chapter 1) |
| 10–15 min | Current drill being learned (slow tempo, careful) |
| 10–15 min | Recently mastered drills (at target tempo, for retention) |
| 5–10 min | Free play or a piece you're working on (not drill book) |

The "free play" at the end is essential — it integrates drill skills into
musical context. Don't skip it.

---

## Weekly schedule template

| Day | Focus |
|-----|---|
| Monday | New drill (slow, careful) |
| Tuesday | Same new drill (build tempo) |
| Wednesday | New drill in a different key |
| Thursday | New drill at target tempo + review |
| Friday | Apply new drill to a chord cycle from chapter 10 |
| Saturday | Free play with all current skills |
| Sunday | Rest, or light review |

---

## Phase timeline (9–12 months total)

### Months 1–2: Chapter 1 + 2 (single-hand foundations + zigzag)

Most students should spend more time here than they want to. The LH's
single-hand fluency is the foundation for everything that follows.

- Week 1–2: Bass pulse + alternating bass (1.1, 1.2)
- Week 3: Stride bass (1.3) — harder, takes a week alone
- Week 4–5: Alberti (2.1) in C major, drilled extensively
- Week 6: Alberti in G, F, B♭, E♭ (rotate)
- Week 7: Murky bass (2.2), Reverse Alberti (2.3)
- Week 8: Cascading (2.4), Inner-bounce (2.5)
- Week 9: Pattern switching (2.6)

### Months 3: Chapter 3 (linear arpeggios)

- Week 1: Triple arpeggio in 3/4 (3.1), reverse triple (3.6)
- Week 2: Triple + rest (3.2), reverse + rest (3.7)
- Week 3: Continuous ascent (3.3), octave climb (3.5)
- Week 4: Sextuplet ascent (3.4), octave descent (3.8)

### Month 4: Chapter 4 (two-hand alternation)

- Week 1–2: Oom-pah (4.1) — extensive practice in multiple keys
- Week 3: Waltz bass (4.2)
- Week 4: Slow oom-pah (4.3)

### Month 5: Chapter 5 (block and rolled)

- Week 1: Block chord (5.1), standard roll (5.2)
- Week 2: Slow roll (5.3), reverse roll (5.4)
- Week 3: Étouffé block (5.5), fast roll (5.9)
- Week 4: Staggered roll (5.6), outward/inward rolls (5.7, 5.8)

### Months 6–7: Chapter 6 (layered textures — the hardest)

Spend more time here. The pedal-point discipline (not re-attacking the
LH when chords change) is the *single most important technique* in the
book, and it takes weeks to internalize.

- Weeks 1–2: Pedal point alone (6.1) — 20 minutes a day, just this
- Week 3: Pedal + chord pulse (6.2)
- Weeks 4–5: Pedal + Alberti (6.3) — the canonical hymn texture
- Weeks 6–7: Pedal + arpeggio (6.4)
- Week 8: Combination drills from chapters 1–6

### Month 8: Chapter 7 (wide-spread and cross-hand)

- Week 1: Wide arpeggio (7.1)
- Week 2: Bell tones (7.2)
- Week 3: Cross-hand cascade (7.3)
- Week 4: Application and review

### Months 9–10: Chapters 8 + 9 (modifiers and gestures)

These chapters are faster because each drill builds on already-mastered
foundations.

- Weeks 1–2: Common-tone, passing tones, anticipations (8.1, 8.2, 8.4)
- Week 3: Suspensions (8.5, 8.6, 8.7)
- Week 4: Remaining modifiers (8.3, 8.8 – 8.13)
- Weeks 5–6: Glissando family (9.1 – 9.5)
- Week 7: Harmonics (9.6, 9.7)
- Week 8: Tremolos and trills (9.8 – 9.10)

### Months 11–12: Chapter 10 (chord-cycle expansion)

The fluency phase. Take any pattern you've mastered and run it through
all six chord cycles, in all four available keys.

- Weeks 1–2: Apply 6 most-used patterns (Alberti, Triple arp, Oom-pah,
  Rolled chord, Pedal+Alberti, Wide arp) through the cadential
  cycle (10.1)
- Weeks 3–4: Same 6 patterns through cycles 10.2, 10.3
- Weeks 5–6: Through Pachelbel (10.4) and jazz turnaround (10.5)
- Weeks 7–8: Full diatonic walk (10.6) in all four keys

---

## Signs you're ready to move on

For each drill, mastery means:

- Played at target tempo with no fingering hesitation
- Even velocity across all notes within the cycle
- Smooth transitions across bar lines (no audible "restart" at the bar)
- Clean execution in at least three keys (not just C major)
- Comfortable enough that you can think about something else (the text
  of a hymn, the listener's experience, the next phrase) while playing

If you can do all five for a drill, move on. If any one is shaky, stay
another week.

---

## What to do when stuck

Three diagnostic questions if a drill isn't progressing:

1. **Is the tempo too fast?** Drop to half-speed and rebuild. Most stuck
   drills are stuck because the player advanced tempo too quickly.

2. **Is the fingering wrong?** Some patterns have a non-obvious finger
   pattern. If you're awkwardly stretching, try a different finger
   assignment.

3. **Is the previous drill actually mastered?** Most stuck drills trace
   back to incomplete prerequisites. Go back one drill and see if it's
   really solid.

If all three are accounted for and the drill still won't come, set it
aside for a week and come back. Spaced practice consolidates motor
learning; sometimes a week away does what another hour cannot.

---

## After the book

Once the curriculum is complete (~9–12 months), you have the physical
vocabulary to arrange any diatonic hymn for lever harp from scratch.
At that point, the practice shifts from drill work to:

- Reading hymns and *deciding* which textures fit them
- Arranging multi-verse hymns where each verse uses different textures
- Composing original music using the vocabulary
- Returning to specific drills as needed for refinement

The drill book is the foundation, not the destination. But without the
foundation, everything above is built on sand.
