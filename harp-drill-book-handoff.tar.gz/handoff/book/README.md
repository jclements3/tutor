# Harp Drill Book

**A pedagogical curriculum for 33-string lever harp, C2–A6, strictly diatonic.**

This book builds the physical vocabulary needed to arrange hymns and similar
pieces idiomatically on the lever harp. Drills are organized by pattern family
and ordered so each new skill depends only on previously-mastered ones.

The instrument assumption throughout: 33-string lever harp, range C2–A6, with
levers set once at the start of a piece and never changed mid-piece. Every
drill is strictly diatonic to its home key.

---

## How to use

Each drill is a short ABC-notated exercise. The notation shows the *shape* of
the pattern in one key; the player transposes to other keys by reading the
shape and applying it to whichever diatonic chord cycle the drill specifies.

Tempos given are practice targets. Start at half the listed tempo if needed
and work up. Even velocity across notes is more important than speed.

The chapters follow a strict pedagogical order: each chapter depends on
mastery of the previous one. Within a chapter, drills are also ordered so
the simplest comes first.

---

## Table of contents

- [Preface](00-preface.md)
- [Notation, fingerings, posture](00-notation.md)
- [Chapter 1 — Single-hand foundations](01-single-hand-foundations.md)
- [Chapter 2 — Zigzag patterns](02-zigzag-patterns.md)
- [Chapter 3 — Linear arpeggios](03-linear-arpeggios.md)
- [Chapter 4 — Two-hand alternation](04-two-hand-alternation.md)
- [Chapter 5 — Block and rolled chords](05-block-and-rolled.md)
- [Chapter 6 — Layered textures](06-layered-textures.md)
- [Chapter 7 — Wide-spread and cross-hand](07-wide-spread.md)
- [Chapter 8 — Modifiers](08-modifiers.md)
- [Chapter 9 — Gestures](09-gestures.md)
- [Chapter 10 — Chord-cycle expansion](10-chord-cycles.md)
- [Appendix A — Chord voicings on the lever harp](appendix-a-voicings.md)
- [Appendix B — Available keys and string layouts](appendix-b-keys.md)
- [Appendix C — Recommended practice routine](appendix-c-routine.md)
- [Appendix D — Index of drills](appendix-d-index.md)

---

**58 drills across 10 chapters.**
