# Chapter 1 — Single-hand foundations

These are the simplest drills in the book. They build the LH's ability to
keep steady time on the harmonic foundation while the hand changes pitch.
Master these before anything else; every later drill assumes the LH can do
this work without conscious thought.

---

## 1.1 Bass pulse

**Hand:** LH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I in C major

The simplest drill. One bass note per beat, four beats per chord. The pitch
changes on the bar line; the rhythm stays metronomic.

```abc
X:1
T:1.1 Bass pulse
M:4/4
L:1/4
K:C
"C" C,4 | "F" F,4 | "G" G,,4 | "C" C,4 |
```

**Practice in keys:** C, G, D, F, B♭, E♭, A♭ (all seven lever-harp keys)
**Mastery criterion:** completely steady quarter notes for four full
cycles; the chord change at each bar line is heard from the new pitch
alone, not from any timing hiccup.

**Common error:** dragging into the chord change. The bass note on beat 1
of the new bar should arrive *exactly* one beat after the previous bass
note, regardless of how far the hand had to travel.

---

## 1.2 Alternating bass (root–5th)

**Hand:** LH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Bass on beats 1 and 3, 5th of the chord on beats 2 and 4. Adds an
across-the-octave hand motion to the steady pulse.

```abc
X:1
T:1.2 Alternating bass
M:4/4
L:1/4
K:C
"C" C, G, C, G, | "F" F, C F, C | "G" G,, D, G,, D, | "C" C, G, C, G, |
```

**Practice in keys:** all seven
**Mastery criterion:** the leap from root to 5th and back is smooth; the
root note's ring carries through the 5th's attack and back.

**Common error:** the 5th is plucked harder than the root, accenting the
weak beats. Keep velocity even across all four beats.

---

## 1.3 Stride bass

**Hand:** LH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 70 bpm (slower; this is harder)
**Cycle:** I – IV – V – I

Bass note on beats 1 and 3; the full chord (or a portion of it) on beats
2 and 4, all played by the LH alone. The hand leaps between low bass
and middle-register chord on every beat. This frees the RH for melody
in real playing.

```abc
X:1
T:1.3 Stride bass
M:4/4
L:1/4
K:C
"C" C,, [CEG] C,, [CEG] | "F" F,, [FAc] F,, [FAc] | "G" G,, [GBd] G,, [GBd] | "C" C,, [CEG] C,, [CEG] |
```

**Practice in keys:** C, G, F, D (the easier reach keys first)
**Mastery criterion:** the bass-to-chord leap is reliable; no string is
accidentally caught during the jump; chord attacks have all three notes
landing simultaneously.

**Common error:** the LH's chord on the "and" beat is rolled instead of
struck. Stride bass uses a *block* chord on the offbeats, not a roll.
Keep the chord crisp.
