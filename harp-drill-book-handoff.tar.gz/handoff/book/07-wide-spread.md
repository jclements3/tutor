# Chapter 7 — Wide-spread and cross-hand

These drills exploit the harp's register — chords broken across two or more
octaves, hands moving into different territories, eventually crossing. The
challenge is **span**: the hand reaches farther than in chapters 1–6, and
two-hand coordination must work across larger pitch gaps.

---

## 7.1 Wide arpeggio

**Hand:** two-handed
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Chord arpeggiated across two octaves. LH plays the lower two notes; RH
catches the upper two. Hands sequential, not simultaneous. The pattern
*b·m+8·t·m+16* — bass note, then middle note an octave up, then top
note, then middle note two octaves up from the original.

```abc
X:1
T:7.1 Wide arpeggio
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] zzge' zzge' | zzac" zzac" | zzBd' zzBd' | zzge' zzge' |
[V:LH] "C" C,e zz C,e zz | "F" F,a zz F,a zz | "G" G,,d zz G,,d zz | "C" C,e zz C,e zz |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the LH-to-RH hand-off is smooth; no gap in the
pattern at the octave boundary; the wide reach to the top note
doesn't cause hesitation.

**Common error:** the RH attack arrives late after the LH finishes. The
RH should be in position *before* its first note's beat, ready to
pluck on time.

---

## 7.2 Bell tones

**Hand:** two-handed
**Meter:** 4/4
**Rate:** half notes (one event per 2 beats)
**Tempo target:** 60 bpm
**Cycle:** I – IV – V – I (one chord every 4 beats)

LH plays the bass note. RH plays the same chord-tone note three or four
octaves higher. Both attack simultaneously, then let ring. Creates a
bell-like sonority — bass anchor plus high chime, nothing in between.

```abc
X:1
T:7.2 Bell tones
M:4/4
L:1/2
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] c'2 c'2 | c''2 c''2 | d'2 d'2 | c'2 c'2 |
[V:LH] "C" C,2 C,2 | "F" F,2 F,2 | "G" G,,2 G,,2 | "C" C,2 C,2 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** both hands attack exactly together; the wide
gap between LH and RH doesn't cause one to lag; ring is balanced.

**Common error:** the RH high note is plucked harder than the LH bass
to "carry" — but this disrupts the balance. Keep velocity matched
between the hands.

---

## 7.3 Cross-hand cascade

**Hand:** two-handed, hands cross
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 70 bpm
**Cycle:** I – IV – V – I

LH plays bass, then crosses up to play a middle-register note; RH plays
a high note, then a mid note. The hands interleave in pitch space.
Visually dramatic; produces a "braided" texture. Demanding physically.

```abc
X:1
T:7.3 Cross-hand cascade
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] zc'ze' zc'ze' | zc"zf" zc"zf" | zd'zg' zd'zg' | zc'ze' zc'ze' |
[V:LH] "C" C,zE,z C,zE,z | "F" F,zA,z F,zA,z | "G" G,,zB,,z G,,zB,,z | "C" C,zE,z C,zE,z |
```

**Practice in keys:** C, G, F
**Mastery criterion:** hands cross without collision; the texture sounds
like a continuous broken chord across both registers; LH and RH
alternation is precise.

**Common error:** the hands collide because the LH reaches up at the
same moment the RH reaches down. Practice slowly; the LH crosses
*above* the RH's previous position, while the RH simultaneously
moves below where the LH is heading.
