# Chapter 8 — Modifiers

Modifiers are decorations applied on top of an already-mastered pattern. Each
one adds a single new event or device to a base pattern (usually Alberti).
Modifiers are where the music becomes *expressive* — the pattern provides
the foundation, the modifier adds the moment of interest.

These drills are quick to learn individually once the underlying pattern is
solid. Don't attempt them until chapter 2 is mastered.

---

## 8.1 Common-tone holdover

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

When two adjacent chords share a tone (C is shared between C major and F
major), the shared tone is *not re-attacked* on the chord change — it
sustains across the bar line. The texture flows seamlessly.

In Alberti pattern: bar 1 (C major) ends on G (top note). Bar 2 (F major)
starts on F — but C and F share the note C as a common tone. The drill:
when transitioning from C to F, hold the C note from the end of bar 1
through the beginning of bar 2 (since both chords contain it).

```abc
X:1
T:8.1 Common-tone holdover
M:4/4
L:1/8
K:C
"C" C,G,E,G, C,G,E,G, | "F" F-(F,CA,C C,CA,C) | "G" G,,DB,,D G,,DB,,D | "C" C,G,E,G, C,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the common-tone bar transition is *silent* — the
listener hears no attack at the bar line, only a chord shift.

**Common error:** restriking the common tone out of pattern habit.
Practice slowly with attention to which note is shared between
adjacent chords.

---

## 8.2 Passing tones

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

The fourth note of each Alberti cycle is replaced with a *passing tone*
that steps toward the next chord's root. The pattern's b·t·m·t shape
becomes b·t·m·passing.

```abc
X:1
T:8.2 Passing tones
M:4/4
L:1/8
K:C
"C" C,G,E,F, C,G,E,F, | "F" F,CA,B, F,CA,B, | "G" G,,DB,,C, G,,DB,,C, | "C" C,G,E,G, C,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** each passing tone is heard as *leading* the ear
into the next chord; bar lines are softened.

---

## 8.3 Neighbor tones

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Within a single chord, the pattern decorates one note with a *neighbor*
— a step up or down and back. Adds melodic interest without changing
harmony.

```abc
X:1
T:8.3 Neighbor tones
M:4/4
L:1/8
K:C
"C" C,G,E,F,E,G,E,G, | "F" F,CA,B,A,CA,C | "G" G,,DB,,C,B,,DB,,D | "C" C,G,E,F,E,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the neighbor figure is audible as ornament
without disrupting the underlying chord's clarity.

---

## 8.4 Anticipations

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

The last note of each bar is replaced with the *next chord's bottom
note*, anticipating the chord change one eighth note early. The new
bass arrives on the "and" of beat 4 instead of beat 1.

```abc
X:1
T:8.4 Anticipations
M:4/4
L:1/8
K:C
"C" C,G,E,G, C,G,E,F, | "F" F,CA,C F,CA,G,, | "G" G,,DB,,D G,,DB,,C, | "C" C,G,E,G, C,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the anticipated bass note is heard as
*foreshadowing*, not as an early mistake.

---

## 8.5 4-3 suspension

**Hand:** RH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 70 bpm
**Cycle:** V – I (repeated)

At the V to I resolution, the 4th of I (the F over C major) is held over
from the previous V7 chord's 7th, then resolves down by step to the 3rd
(E). The classic textbook dissonance.

```abc
X:1
T:8.5 4-3 suspension
M:4/4
L:1/4
K:C
"G7" [GBdf]2 [GBdf]2 | "C" f2 e2 | "G7" [GBdf]2 [GBdf]2 | "C" f2 e2 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the F over the C chord is heard as a *tension*
that wants to resolve; the resolution to E completes the figure.

---

## 8.6 9-8 suspension

**Hand:** RH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 70 bpm
**Cycle:** ii – V – I (repeated)

The 9th of V (A over G) suspends, resolving down to the 8th/root (G).
Same shape as 4-3 suspension, one degree higher.

```abc
X:1
T:9-8 suspension
M:4/4
L:1/4
K:C
"Dm7" [DFAc]2 [DFAc]2 | "G" a2 g2 | "C" g2 g2 | z4 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the A over G is heard as dissonance; resolves
cleanly down to G.

---

## 8.7 7-6 suspension

**Hand:** RH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 70 bpm
**Cycle:** I – vi (repeated)

The 7th of one chord (B over C) suspends into the next chord (vi /
A minor), where it becomes the *6th* of the new chord — a non-chord
tone that resolves down to A.

```abc
X:1
T:8.7 7-6 suspension
M:4/4
L:1/4
K:C
"C" [ceg]2 [ceg]2 | "Am" b2 a2 | "C" [ceg]2 [ceg]2 | "Am" b2 a2 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the B over A minor is heard as dissonance;
resolves to A.

---

## 8.8 Anticipated bass

**Hand:** LH alone
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

The bass plays the next chord's root one beat early, becoming an inner
voice for that beat before settling on the new chord's downbeat.

```abc
X:1
T:8.8 Anticipated bass
M:4/4
L:1/4
K:C
"C" C, C, C, F, | "F" F, F, F, G,, | "G" G,, G,, G,, C, | "C" C, C, C, C, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the anticipated bass note (beat 4 of each bar)
is audibly *the next chord's* root, leading smoothly into bar 1 of
the next bar.

---

## 8.9 Bell-note accent

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Standard Alberti, but one note per cycle is played *fortissimo* — usually
the top note of beat 1's "and." Creates a melodic accent emerging from
the texture.

```abc
X:1
T:8.9 Bell-note accent
M:4/4
L:1/8
K:C
"C" C,!ff!G,E,G, C,G,E,G, | "F" F,!ff!CA,C F,CA,C | "G" G,,!ff!DB,,D G,,DB,,D | "C" C,!ff!G,E,G, C,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the accent note is clearly louder but doesn't
disrupt the surrounding pattern's evenness.

---

## 8.10 Octave doubling pop

**Hand:** LH or RH (the pattern's home hand)
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Within an Alberti pattern, one note is *doubled at the octave* —
played as a two-note chord — for emphasis. A brief thicker moment
that pops out without changing the pattern's shape.

```abc
X:1
T:8.10 Octave doubling pop
M:4/4
L:1/8
K:C
"C" C,G,E,[gg'] C,G,E,G, | "F" F,CA,[c'c''] F,CA,C | "G" G,,DB,,[dd'] G,,DB,,D | "C" C,G,E,[gg'] C,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the doubled note is audible as a thicker moment
without disrupting tempo.

---

## 8.11 Mid-pattern pause

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes with one 16th rest
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

A 16th-note rest inserted mid-cycle. The hand briefly lifts, creating a
"hiccup" or breath within the pattern.

```abc
X:1
T:8.11 Mid-pattern pause
M:4/4
L:1/16
K:C
"C" C,2G,2E,2G,2 C,2zG,2E,2G,2 | "F" F,2C2A,2C2 F,2zC2A,2C2 | "G" G,,2D2B,,2D2 G,,2zD2B,,2D2 | "C" C,2G,2E,2G,2 C,2zG,2E,2G,2 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the rest is heard as a deliberate breath; the
pattern resumes cleanly afterward.

---

## 8.12 Échappée (escape tone)

**Hand:** LH alone
**Meter:** 4/4
**Rate:** sixteenth notes
**Tempo target:** 70 bpm
**Cycle:** I – IV – V – I

A non-chord tone is reached by step, then jumps *back* (rather than
continuing in the same direction) to a chord tone. The "escape" is
brief and ornamental.

```abc
X:1
T:8.12 Echappee
M:4/4
L:1/16
K:C
"C" C,E,G,A,G,E,C,2 C,E,G,A,G,E,C,2 | "F" F,A,cd cA,F,2 F,A,cd cA,F,2 | "G" G,,B,,DE DB,,G,,2 G,,B,,DE DB,,G,,2 | "C" C,E,G,A,G,E,C,2 C,E,G,A,G,E,C,2 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the escape note is heard as ornament; the return
to a chord tone happens cleanly.

---

## 8.13 Anticipated cadence note

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

One note from the *upcoming cadence chord* is played a beat early,
embedded in the previous bar's pattern. Specifically: the tonic note
of the final I chord is played on the "and" of beat 4 of the V chord.

```abc
X:1
T:8.13 Anticipated cadence note
M:4/4
L:1/8
K:C
"C" C,G,E,G, C,G,E,G, | "F" F,CA,C F,CA,C | "G" G,,DB,,D G,,DB,,C, | "C" C,G,E,G, C,G,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the anticipated tonic note is heard as a
foreshadowing of the cadence; the resolution to I feels prepared.
