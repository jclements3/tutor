# Appendix B — Available keys and string layouts

The 33-string lever harp tuned to E♭ major (base position, all levers down)
sounds these pitches across its range:

```
String:  C2  D2  E♭2 F2  G2  A♭2 B♭2  C3  D3  E♭3 F3  G3  A♭3 B♭3  C4  D4  E♭4 F4  G4  A♭4 B♭4  C5  D5  E♭5 F5  G5  A♭5 B♭5  C6  D6  E♭6 F6  A6
```

That's 32 strings (the lowest is C2, highest is A6). With each lever raising
one string by a half-step, the available keys are:

| Key | Levers up (flats raised) | Sharps gained |
|-----|---|---|
| E♭ major | none | (base position, 3 flats) |
| B♭ major | E♭ levers up → E♮ | (2 flats: B♭, A♭) |
| F major | E♭ and A♭ levers up → E♮ and A♮ | (1 flat: B♭) |
| C major | E♭, A♭, B♭ all up → E♮, A♮, B♮ | (no flats/sharps) |
| G major | C♮ → C♯ (in addition to above) | (1 sharp: F♯ — wait, see below) |

Hmm — there's a subtlety here. The lever harp's levers raise strings by a
half-step. So you can go from E♭ to E♮ (lever up), but you cannot go from
E♮ back down to E♭ without lowering the lever. And critically, you cannot
go *higher* than E♮ — there's no way to get to F♭ (which would equal E♮
enharmonically anyway, but you'd need a lever lowering, not raising).

The practical consequence: **going sharper than C major requires sharp
strings, which the E♭-tuned lever harp doesn't have.**

So the realistic set of keys for this instrument is:

| Key | How to set |
|-----|---|
| E♭ major | base (no levers) |
| B♭ major | E♭ levers up |
| F major | E♭, A♭ levers up |
| C major | E♭, A♭, B♭ all up |

**Four keys** in the major mode, not seven. The sharper keys (G, D, A,
etc.) cannot be played on an E♭-tuned lever harp without retuning the
instrument.

If your harp is tuned to **C major base** (no levers raised gives C
major, three flats inactive on the instrument because there are no flat
strings), then:

| Key | How to set |
|-----|---|
| C major | base |
| G major | F levers up → F♯ |
| D major | F and C levers up → F♯ and C♯ |
| A major | F, C, G levers up |
| E major | F, C, G, D levers up |
| B major | F, C, G, D, A levers up |
| F♯ major | F, C, G, D, A, E levers up |

A C-tuned lever harp gets **all the sharp keys**, but no flat keys.

A flat-side instrument (E♭ base) gets **flat keys**, no sharp keys.

The instrument you're targeting (33-string E♭ base) is the flat-side
configuration. Its key options are E♭, B♭, F, C — four major keys, plus
their relative minors (C minor, G minor, D minor, A minor).

---

## Practice key recommendations

For the drill book, practice in:

- **C major** — the simplest, no flats or sharps visible
- **F major** — adds one flat (B♭)
- **B♭ major** — adds two flats (B♭, E♭)
- **E♭ major** — base position, three flats

That covers the available major keys without retuning.

For minor-key practice:
- **A minor** — relative of C
- **D minor** — relative of F
- **G minor** — relative of B♭
- **C minor** — relative of E♭

---

## Setting the levers

Always set the levers *before* you start playing. Mid-piece lever changes
are slow and physically disruptive — the rule of this book is "set once,
never change."

To set the levers:

1. Identify the key. (For "Blessed Jesus, at Thy Word" you'd target G
   major if your harp were C-tuned, but on an E♭-tuned harp you'd
   transpose to F major.)
2. Determine which levers must be raised. (For F major from E♭ base:
   raise the A♭ string to A♮.)
3. Lift each lever physically (one at a time) until it engages. Confirm
   by plucking the string and checking pitch.
4. Lock posture in playing position and start.

The lever-setting itself is a skill. Practicing the *transition* — going
from idle hands to lever-setting and back — is worth doing as its own
brief drill.
