# Chapter 5 — Block and rolled chords

These drills cover single-event chord attacks rather than continuous patterns.
Block and rolled chords are the harp's punctuation marks — used at openings,
arrivals, and cadences. They sit at the boundary between "pattern" (chapters
1–4) and "gesture" (chapter 9), but they appear here because they're the
foundational chord-attack techniques every later texture relies on.

---

## 5.1 Block chord

**Hand:** two-handed
**Meter:** 4/4
**Rate:** one chord per bar
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

All chord tones struck simultaneously, let ring for the full bar. The
simplest chord attack. Despite its simplicity, perfectly synchronized
attack across both hands is harder than it sounds.

```abc
X:1
T:5.1 Block chord
M:4/4
L:1/1
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] [ceg]1 | [fac']1 | [GBd]1 | [ceg]1 |
[V:LH] "C" [C,E,G,]1 | "F" [F,A,c]1 | "G" [G,,B,,D]1 | "C" [C,E,G,]1 |
```

**Practice in keys:** all seven
**Mastery criterion:** every note in the chord — across both hands —
attacks at exactly the same moment. No audible roll, no flam.

**Common error:** the LH's bass note lands slightly ahead of the RH
chord. Practice with the RH alone, then LH alone, then both — match
the timing.

---

## 5.2 Standard rolled chord

**Hand:** two-handed
**Meter:** 4/4
**Rate:** one rolled event per bar
**Tempo target:** 70 bpm (each roll takes ~1/4 beat)
**Cycle:** I – IV – V – I

The signature harp gesture. All chord notes plucked bottom-to-top very
fast (~16th-note speed), let ring. The whole chord *blooms* into
existence rather than slapping.

```abc
X:1
T:5.2 Standard rolled chord
M:4/4
L:1/1
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] (3ceg z3/2 | (3fac' z3/2 | (3GBd z3/2 | (3ceg z3/2 |
[V:LH] "C" (3C,E,G, z3/2 | "F" (3F,A,c z3/2 | "G" (3G,,B,,D z3/2 | "C" (3C,E,G, z3/2 |
```

**Practice in keys:** all seven
**Mastery criterion:** the roll across both hands is even — no
acceleration through the roll; the LH's bottom note ringing through
the RH's notes; final chord sustains uniformly across all pitches.

**Common error:** the LH and RH halves of the roll aren't connected;
there's a gap between the LH's top note and the RH's bottom note.
The whole roll should be a single unbroken motion.

---

## 5.3 Slow roll

**Hand:** two-handed
**Meter:** 4/4
**Rate:** rolled event takes ~1/2 beat
**Tempo target:** 60 bpm
**Cycle:** I – V – I (one chord per 2 bars)

A theatrical, slow roll. Each note is audible as a separate event during
the roll. Used for fermata moments, cadenza-like passages, dramatic
arrivals.

```abc
X:1
T:5.3 Slow roll
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] cege z4 | dBdG, z4 | cege z4 | cege z4 |
[V:LH] "C" C,E,G,c z4 | "G" G,,DGB z4 | "C" C,E,G,c z4 | "C" C,E,G,c z4 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** every note in the roll is heard as a distinct
event; the roll is even (each note takes equal time); ring fills the
remaining bar.

---

## 5.4 Reverse roll (top-down)

**Hand:** two-handed
**Meter:** 4/4
**Rate:** one rolled event per bar
**Tempo target:** 70 bpm
**Cycle:** I – V – I

Top-to-bottom roll. Mirror image of standard roll. Physically harder
because the hands resist descending motion. Used for descending phrases
or "fall" gestures.

```abc
X:1
T:5.4 Reverse roll
M:4/4
L:1/1
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] (3gec z3/2 | (3dBG z3/2 | (3gec z3/2 | (3gec z3/2 |
[V:LH] "C" (3G,E,C, z3/2 | "G" (3DB,,G,, z3/2 | "C" (3G,E,C, z3/2 | "C" (3G,E,C, z3/2 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the descending roll is as even as the ascending
roll; no acceleration as the hand falls toward the bass.

---

## 5.5 Étouffé block

**Hand:** two-handed
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I (one chord per beat — fast harmonic rhythm)

Block chord struck and immediately damped with the palm. A short, dry,
percussive sound. Notation here uses staccato dots; in real engraving
this is marked with a + sign or the word "étouffé".

```abc
X:1
T:5.5 Etouffe block
M:4/4
L:1/4
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] [c.e.g.] [f.a.c'.] [G.B.d.] [c.e.g.] | [c.e.g.] [f.a.c'.] [G.B.d.] [c.e.g.] | [c.e.g.] [f.a.c'.] [G.B.d.] [c.e.g.] | [c.e.g.] [f.a.c'.] [G.B.d.] [c.e.g.] |
[V:LH] "C" C,. "F" F,. "G" G,,. "C" C,. | C,. F,. G,,. C,. | C,. F,. G,,. C,. | C,. F,. G,,. C,. |
```

**Practice in keys:** all seven
**Mastery criterion:** every chord is dry — no audible ring after the
damping; attacks are crisp; tempo is steady despite the rapid
harmonic rhythm.

**Common error:** the damping isn't physical. Étouffé requires the
*palm or fingers actually pressing the strings* to stop them, not
just lifting the plucking fingers.

---

## 5.6 Staggered roll across hands

**Hand:** two-handed
**Meter:** 4/4
**Rate:** rolled event with hand offset
**Tempo target:** 60 bpm
**Cycle:** I – V – I (slow)

LH rolls first, then RH rolls just after (~16th-note offset). Creates
a "cathedral chord" effect — like two harps slightly out of sync. Used
at major structural arrivals.

```abc
X:1
T:5.6 Staggered roll
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] z(3ceg z5 | z(3GBd z5 | z(3ceg z5 | z(3ceg z5 |
[V:LH] "C" (3C,E,G, z6 | "G" (3G,,DB,, z6 | "C" (3C,E,G, z6 | "C" (3C,E,G, z6 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the gap between LH roll completion and RH roll
start is consistent — about one 16th note. The whole chord ultimately
rings as a unit but the arrival is *staggered*.

---

## 5.7 Outward roll

**Hand:** two-handed
**Meter:** 4/4
**Rate:** rolled event per bar
**Tempo target:** 70 bpm
**Cycle:** I – V – I

Starts at the middle of the chord, expands outward to both extremes
simultaneously. Bell-like effect. Rare but useful for special moments.

```abc
X:1
T:5.7 Outward roll
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] eg z6 | df z6 | eg z6 | eg z6 |
[V:LH] "C" "C" C,G,, z6 | "G" "G" G,,B,,, z6 | "C" "C" C,G,, z6 | "C" "C" C,G,, z6 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the two outward motions (LH going down, RH going
up) are synchronized; they reach their extremes at the same moment.

---

## 5.8 Inward roll

**Hand:** two-handed
**Meter:** 4/4
**Rate:** rolled event per bar
**Tempo target:** 70 bpm
**Cycle:** I – V – I

The reverse of outward roll. Starts at the extremes (top and bottom
simultaneously), converges to the middle. Collapsing-inward feel,
modernist character.

```abc
X:1
T:5.8 Inward roll
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] ge z6 | fd z6 | ge z6 | ge z6 |
[V:LH] "C" G,,C, z6 | "G" B,,,G,, z6 | "C" G,,C, z6 | "C" G,,C, z6 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the convergence to the middle is smooth; both
hands reach the inner notes at the same moment.

---

## 5.9 Fast roll (flam)

**Hand:** two-handed
**Meter:** 4/4
**Rate:** very fast roll, faster than standard
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Roll faster than 16th-note speed — almost instantaneous, but still
audibly a roll rather than a block chord. Used when you want chord
clarity with bloom but not the slap of a pure block.

```abc
X:1
T:5.9 Fast roll
M:4/4
L:1/16
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] ceg z13 | fac' z13 | GBd z13 | ceg z13 |
[V:LH] "C" C,E,G, z13 | "F" F,A,c z13 | "G" G,,B,,D z13 | "C" C,E,G, z13 |
```

**Practice in keys:** all seven
**Mastery criterion:** the roll is fast enough to be heard as a single
event with bloom; not so fast it becomes a block; consistent across
all four bars.
