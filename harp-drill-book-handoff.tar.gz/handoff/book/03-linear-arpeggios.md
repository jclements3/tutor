# Chapter 3 — Linear arpeggios

Where zigzag patterns bounce between low and high, linear arpeggios move in
one direction — bottom to top (ascending) or top to bottom (descending) —
per cycle. They produce a more *flowing* feel than zigzag's bounce, and
they're the natural choice for triple-meter pieces (3/4, 6/8, 9/8) where the
three-note groups fit the meter exactly.

---

## 3.1 Triple arpeggio (3/4)

**Hand:** LH alone
**Meter:** 3/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I in 3/4

The cleanest entry to ascending arpeggios. Three notes (b-m-t) per group,
two groups per bar in 3/4, fits the meter naturally.

```abc
X:1
T:3.1 Triple arpeggio
M:3/4
L:1/8
K:C
"C" C,E,G, C,E,G, | "F" F,A,c F,A,c | "G" G,,B,,D G,,B,,D | "C" C,E,G, C,E,G, |
```

**Practice in keys:** all seven
**Mastery criterion:** even eighths through the rising shape; the top
note doesn't get rushed or stretched.

**Common error:** accelerating through the cycle — the top note arriving
early. Use a metronome until the cycle is perfectly even.

---

## 3.2 Triple + rest (4/4)

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I

Three-note arpeggio with an audible rest. The rest is part of the pattern;
the hand should lift visibly to articulate it.

```abc
X:1
T:3.2 Triple + rest
M:4/4
L:1/8
K:C
"C" C,E,G,z C,E,G,z | "F" F,A,cz F,A,cz | "G" G,,B,,Dz G,,B,,Dz | "C" C,E,G,z C,E,G,z |
```

**Practice in keys:** all seven
**Mastery criterion:** the rest is *heard* as a breath; the hand
actually releases from the strings.

**Common error:** filling the rest with continued ring from the previous
note. Damp the strings on the rest.

---

## 3.3 Continuous ascent

**Hand:** two-handed
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

Four-note ascending pattern that uses two hands: LH plays the lower three
notes (b-m-t), RH catches the top note an octave above the bottom. Each
cycle climbs higher before resetting.

```abc
X:1
T:3.3 Continuous ascent
M:4/4
L:1/8
K:C
%%score (LH) (RH)
V:LH clef=bass
V:RH clef=treble
[V:LH] "C" C,E,G,z C,E,G,z | "F" F,A,cz F,A,cz | "G" G,,B,,Dz G,,B,,Dz | "C" C,E,G,z C,E,G,z |
[V:RH] zzzc zzzc | zzzf zzzf | zzzg zzzg | zzzc zzzc |
```

**Practice in keys:** C, G, F (start with these; sharper keys need
careful range awareness)
**Mastery criterion:** the RH's top-note attack is synchronized with
where the LH would have played a fourth note; no audible gap between
LH and RH portions of the cycle.

**Common error:** the RH attack arrives late. Set the RH thumb on the
target string *before* the LH finishes its three-note climb.

---

## 3.4 Sextuplet ascent

**Hand:** LH alone
**Meter:** 4/4
**Rate:** sixteenth notes (six per beat)
**Tempo target:** 60 bpm (slow; this is fast at any tempo)
**Cycle:** I – IV – V – I

Two cycles of b-m-t per beat, in sixteenth notes. Fast, ornamental,
characteristically harp-like. Found in Debussy and Tournier.

```abc
X:1
T:3.4 Sextuplet ascent
M:4/4
L:1/16
K:C
"C" C,E,G,C,E,G, C,E,G,C,E,G, C,E,G,C,E,G, C,E,G,C,E,G, | "F" F,A,cF,A,c F,A,cF,A,c F,A,cF,A,c F,A,cF,A,c | "G" G,,B,,DG,,B,,D G,,B,,DG,,B,,D G,,B,,DG,,B,,D G,,B,,DG,,B,,D | "C" C,E,G,C,E,G, C,E,G,C,E,G, C,E,G,C,E,G, C,E,G,C,E,G, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** even sixteenths throughout; no audible
acceleration through the cycle; equal volume on every note.

**Common error:** the second iteration of each beat accelerates because
the fingers know the pattern and rush ahead. Use a metronome at the
sixteenth-note level if possible.

---

## 3.5 Octave climb

**Hand:** two-handed
**Meter:** 4/4
**Rate:** sixteenth notes
**Tempo target:** 70 bpm
**Cycle:** I – IV – V – I

The chord arpeggiated across two octaves. LH plays the lower octave;
RH continues with the upper octave. Six-note pattern total.

```abc
X:1
T:3.5 Octave climb
M:4/4
L:1/16
K:C
%%score (LH) (RH)
V:LH clef=bass
V:RH clef=treble
[V:LH] "C" C,E,G, z3 C,E,G, z3 | "F" F,A,c z3 F,A,c z3 | "G" G,,B,,D z3 G,,B,,D z3 | "C" C,E,G, z3 C,E,G, z3 |
[V:RH] z3 ceg z3 ceg | z3 fac' z3 fac' | z3 GBd z3 GBd | z3 ceg z3 ceg |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the hand-off between LH and RH is seamless; the
six-note ascending shape sounds continuous, not interrupted at the
octave boundary.

---

## 3.6 Reverse triple arpeggio

**Hand:** LH alone
**Meter:** 3/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I in 3/4

Top-to-bottom descending arpeggio. Three-note groups in 3/4. Physically
harder than the ascending version because the hand resists descending
motion — fingers naturally open *upward* during a pluck.

```abc
X:1
T:3.6 Reverse triple arpeggio
M:3/4
L:1/8
K:C
"C" G,E,C, G,E,C, | "F" cA,F, cA,F, | "G" DB,,G,, DB,,G,, | "C" G,E,C, G,E,C, |
```

**Practice in keys:** all seven
**Mastery criterion:** evenness on the descent; no acceleration as the
hand falls toward the bass.

---

## 3.7 Reverse + rest

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I

Descending three-note arpeggio with audible rest. The rest gives the
hand time to reset for the next descent.

```abc
X:1
T:3.7 Reverse + rest
M:4/4
L:1/8
K:C
"C" G,E,C,z G,E,C,z | "F" cA,F,z cA,F,z | "G" DB,,G,,z DB,,G,,z | "C" G,E,C,z G,E,C,z |
```

**Practice in keys:** all seven
**Mastery criterion:** the rest is heard; the hand reset is invisible
in the rhythm.

---

## 3.8 Octave descent

**Hand:** two-handed
**Meter:** 4/4
**Rate:** sixteenth notes
**Tempo target:** 70 bpm
**Cycle:** I – V – I (slow harmonic rhythm)

Two-octave descending arpeggio. RH starts at the top, LH catches the
lower octave.

```abc
X:1
T:3.8 Octave descent
M:4/4
L:1/16
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] "C" gec z3 gec z3 | "G" dBG, z3 dBG, z3 | "C" gec z3 gec z3 | "C" gec z3 gec z3 |
[V:LH] z3 G,E,C, z3 G,E,C, | z3 DB,,G,, z3 DB,,G,, | z3 G,E,C, z3 G,E,C, | z3 G,E,C, z3 G,E,C, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the descent is continuous across the
hand-handoff; no audible break between RH and LH portions.
