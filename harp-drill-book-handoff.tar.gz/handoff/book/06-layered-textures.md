# Chapter 6 — Layered textures (sustain + motion)

These are the hardest drills in the core curriculum because they require
**simultaneous slow and fast motion in two hands**. One hand holds a note or
chord; the other plays a continuous pattern. The discipline is: the held
hand does *not* re-attack when the harmony changes. The held bass rings
through chord changes; only the moving hand responds to the new chord.

This is the technique that lets the harp express harmony without
piano-stomping. It's why the harp sounds like a harp.

---

## 6.1 Pedal point under changing harmony

**Hand:** two-handed
**Meter:** 4/4
**Rate:** LH whole note; RH quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I (RH chord changes; LH stays on tonic throughout)

LH plays the tonic note C, struck once and held for 4 bars. RH plays the
chord progression on top. The LH is *not* re-attacked when the harmony
changes — the C2 string rings continuously while F major, G major, and
back to C major chords pass above it.

```abc
X:1
T:6.1 Pedal point under changing harmony
M:4/4
L:1/4
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] "C" [ceg][ceg][ceg][ceg] | "F" [fac'][fac'][fac'][fac'] | "G" [GBd][GBd][GBd][GBd] | "C" [ceg][ceg][ceg][ceg] |
[V:LH] C,,16 |  |  |  |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the LH bass note is struck *once* at the start
of the cycle and rings through all four bars without re-attack; the
dissonances between the held bass and the upper chord changes are
heard but not "wrong."

**Common error:** the LH instinctively re-attacks at each chord change.
This is the single hardest habit to break, and the most important one
in the whole book. The held bass is the harp's foundational technique.

---

## 6.2 Pedal + chord pulse

**Hand:** two-handed
**Meter:** 4/4
**Rate:** LH whole note; RH quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

LH holds bass note. RH plays the current chord as a single block on each
beat. Same discipline as 6.1 but the RH now changes chord *per bar*, so
the texture has more harmonic motion above the held bass.

```abc
X:1
T:6.2 Pedal + chord pulse
M:4/4
L:1/4
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] "C" [ceg][ceg][ceg][ceg] | "F" [fac'][fac'][fac'][fac'] | "G" [GBd][GBd][GBd][GBd] | "C" [ceg][ceg][ceg][ceg] |
[V:LH] C,,16 |  |  |  |
```

**Practice in keys:** C, G, F
**Mastery criterion:** RH chords land cleanly on every beat with even
velocity; LH ring is preserved through all four bars.

---

## 6.3 Pedal + Alberti

**Hand:** two-handed
**Meter:** 4/4
**Rate:** LH whole note; RH eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

LH holds bass. RH plays full eighth-note Alberti pattern (b·t·m·t) on the
current chord, in the upper register. This is the canonical hymn texture
— it's what gives the gentle hymn arrangements their floating-foundation
feel.

```abc
X:1
T:6.3 Pedal + Alberti
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] "C" cgeg cgeg | "F" fc'a c' fc'a c' | "G" GdBd GdBd | "C" cgeg cgeg |
[V:LH] C,,8 |  |  |  |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the RH Alberti is clean and even at eighth-note
rate; the LH ring persists; the two hands' very different rhythms
don't pull each other off-time.

**Common error:** the RH Alberti slows or speeds up to "match" the
LH's lack of motion. The two hands are independent — the RH stays at
strict eighth-note rate regardless of what the LH is doing.

---

## 6.4 Pedal + arpeggio

**Hand:** two-handed
**Meter:** 4/4
**Rate:** LH whole note; RH sixteenth notes
**Tempo target:** 60 bpm (slow; this is fast for RH)
**Cycle:** I – IV – V – I

LH holds. RH plays a continuous sixteenth-note arpeggio (b·m·t·b·m·t per
beat, six sixteenths) on the current chord. More florid version of 6.3
— used for ornamented hymn passages or interludes.

```abc
X:1
T:6.4 Pedal + arpeggio
M:4/4
L:1/16
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] "C" cegceg cegceg cegceg cegceg | "F" fac'fac' fac'fac' fac'fac' fac'fac' | "G" GBdGBd GBdGBd GBdGBd GBdGBd | "C" cegceg cegceg cegceg cegceg |
[V:LH] C,,16 |  |  |  |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the RH sixteenth-note arpeggio is even
throughout; no acceleration; LH ring carries through 24 RH attacks
per bar without being disturbed.

**Common error:** the RH arpeggio loses evenness in the middle of each
beat — the second b·m·t group of each beat is rushed. Use a
metronome at the sixteenth-note level if possible.
