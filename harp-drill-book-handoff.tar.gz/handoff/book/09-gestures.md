# Chapter 9 — Gestures

Gestures are single events rather than continuous patterns. A pattern repeats
across many beats; a gesture happens once, then rings or fades. Gestures are
the harp's *punctuation* — used at phrase openings, climaxes, cadences, and
arrivals.

This chapter assumes mastery of chapters 1–7. Gestures are usually deployed
*between* pattern passages, so you need the patterns in place first.

---

## 9.1 Standard glissando

**Hand:** one hand (either)
**Meter:** 4/4
**Rate:** one sweep, ~1/2 beat
**Tempo target:** 80 bpm
**Cycle:** play once into each chord of I – IV – V – I

Sweep the hand across the strings in pitch order. Pedals (or levers) set
in advance to define which 7 pitches per octave are live. Result: a fast
arpeggio of all currently-tuned strings the hand crosses.

```abc
X:1
T:9.1 Standard glissando
M:4/4
L:1/4
K:C
"C" CDEFGABc | C4 | C4 | C4 |
```

(Notation here shows the gliss pitches in ABC; in real engraving, mark
as a wavy line with start and end notes.)

**Practice in keys:** all seven
**Mastery criterion:** sweep is even — no acceleration; the target
chord rings out after the gliss completes.

---

## 9.2 Slow glissando

**Hand:** one hand
**Meter:** 4/4
**Rate:** sweep takes ~2 beats
**Tempo target:** 60 bpm
**Cycle:** I → I (slow sweep on same chord)

Each string is audible as a separate event during the sweep. Less of a
"gliss effect" and more of a slow arpeggio of the diatonic scale.

```abc
X:1
T:9.2 Slow glissando
M:4/4
L:1/4
K:C
"C" CDEF GABc | c4 | C4 | C4 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** every string is audible; the sweep is even and
controlled.

---

## 9.3 Partial glissando

**Hand:** one hand
**Meter:** 4/4
**Rate:** sweep across a defined range, ~1/2 beat
**Tempo target:** 80 bpm
**Cycle:** I (single chord)

A glissando limited to a specific octave or two-octave range. Used as
ornament rather than structural event. Often goes from a melody note
up to its octave above.

```abc
X:1
T:9.3 Partial glissando
M:4/4
L:1/8
K:C
"C" CDEFGABcdefgabc' | C4 | C4 | C4 |
```

**Practice in keys:** all seven
**Mastery criterion:** the gliss starts and stops at precisely
controlled pitches.

---

## 9.4 Two-hand glissando

**Hand:** both hands
**Meter:** 4/4
**Rate:** sweeps in opposite directions, meet in middle
**Tempo target:** 80 bpm
**Cycle:** I (single chord, full glissando)

LH sweeps down from middle range; RH sweeps up from middle range; they
*meet* at the lowest and highest points. Maximum drama. Used at
section openings or grand cadences.

```abc
X:1
T:9.4 Two-hand glissando
M:4/4
L:1/8
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] cdefgabc'd'e'f' z4 |
[V:LH] "C" CB,A,G,F,E,D,C,B,,A,,G,,F,, z4 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** both hands' sweeps are coordinated — they start
together and finish together at the outer ends of the harp.

---

## 9.5 Snap glissando

**Hand:** one hand, back of hand
**Meter:** 4/4
**Rate:** very fast, almost simultaneous
**Tempo target:** 80 bpm
**Cycle:** I (single chord)

Played with the back of the hand (or a quick rake), the sweep is fast
enough to almost be a strum. Sharp attack. Used for percussive
emphasis.

```abc
X:1
T:9.5 Snap glissando
M:4/4
L:1/16
K:C
"C" CDEFGABc z12 | C4 | C4 | C4 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the snap is fast and crisp; doesn't sound like
a continuous sweep.

---

## 9.6 Harmonic note

**Hand:** one hand
**Meter:** 4/4
**Rate:** single sustained note
**Tempo target:** 60 bpm
**Cycle:** I (long sustained tonic note)

Touch the string at its midpoint with the heel of the palm while
plucking with another finger. The string sounds an octave higher than
its tuned pitch, with a glass-bell timbre. Notation: small circle above
the note.

```abc
X:1
T:9.6 Harmonic note
M:4/4
L:1/1
K:C
"C" !o!c1 | !o!c1 | !o!g1 | !o!c1 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the harmonic is clear — bell-like, an octave
above the plucked string, no fundamental bleed.

**Common error:** the palm doesn't fully damp the fundamental, producing
a muddy mix instead of a pure harmonic.

---

## 9.7 Two-note harmonic chord

**Hand:** one hand
**Meter:** 4/4
**Rate:** single attack
**Tempo target:** 60 bpm
**Cycle:** I (held)

Two harmonics produced simultaneously by one hand. Requires careful
hand position: palm damps both strings at midpoint, two fingers pluck.

```abc
X:1
T:9.7 Two-note harmonic chord
M:4/4
L:1/1
K:C
"C" !o![ce]1 | !o![ce]1 | !o![dg]1 | !o![ce]1 |
```

**Practice in keys:** C, G, F
**Mastery criterion:** both harmonics ring clearly; they're an octave
above the played strings.

---

## 9.8 Trill

**Hand:** one hand (usually RH)
**Meter:** 4/4
**Rate:** sixteenth notes
**Tempo target:** 70 bpm (faster as comfort allows)
**Cycle:** I (held chord with trill above)

Rapid alternation of two adjacent diatonic notes — usually a melody note
and the note above it. The harp can sustain trills longer than the
piano because of ring; particularly effective on long melody notes.

```abc
X:1
T:9.8 Trill
M:4/4
L:1/16
K:C
"C" cdcdcdcd cdcdcdcd cdcdcdcd cdcdcdcd | "F" cdcdcdcd cdcdcdcd cdcdcdcd cdcdcdcd | "G" bcbcbcbc bcbcbcbc bcbcbcbc bcbcbcbc | "C" cdcdcdcd cdcdcdcd cdcdcdcd cdcdcdcd |
```

**Practice in keys:** C, G, F
**Mastery criterion:** trill is even and continuous; no acceleration
or unevenness across the bar.

---

## 9.9 Two-note tremolo

**Hand:** one hand or two-handed
**Meter:** 4/4
**Rate:** sixteenth notes
**Tempo target:** 70 bpm
**Cycle:** I – V – I

Rapid alternation between two notes a 3rd or 4th apart (chord tones).
Faster than a trill, sounds shimmering. Used at climax moments.

```abc
X:1
T:9.9 Two-note tremolo
M:4/4
L:1/16
K:C
"C" cececece cececece cececece cececece | "G" dBdBdBdB dBdBdBdB dBdBdBdB dBdBdBdB | "C" cececece cececece cececece cececece | "C" cececece cececece cececece cececece |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the alternation is fast enough to blur into a
"shimmer"; not so slow that the listener hears two distinct alternating
notes.

---

## 9.10 Bisbigliando

**Hand:** two-handed
**Meter:** 4/4
**Rate:** very fast sixteenth notes
**Tempo target:** 60 bpm
**Cycle:** I – V – I (slow harmonic rhythm)

Italian for "whispering." Hands alternate rapidly across 2–3 adjacent
strings of the current chord. Creates a sustained shimmer effect — the
harp's true tremolo technique.

```abc
X:1
T:9.10 Bisbigliando
M:4/4
L:1/16
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] gegegegeg egegegege gegegegege egegegege |
[V:LH] "C" EGEGEGEG zGEGEGEGE GEGEGEGE zGEGEGEGE |
```

**Practice in keys:** C, G, F
**Mastery criterion:** the two-hand alternation is so fast it sounds
like a single sustained shimmer; the chord is heard as a unit.
