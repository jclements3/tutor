# Preface

This book exists because most harp playing is taught one piece at a time. You
learn a Tournier study, then a Salzedo etude, then a hymn arrangement, and
gradually you absorb the vocabulary of patterns underneath. It works, but
slowly, and the vocabulary stays implicit — you can play the patterns but
can't name them, can't combine them deliberately, can't generate new pieces
from them.

The premise of this book is the opposite: **learn the vocabulary first,
explicitly, as a finite set of drills.** Once the vocabulary is mastered, any
arrangement is a sequence of choices from the drill catalogue. Hymns become
straightforward. Original compositions become tractable. The harp stops being
a piano-like instrument you adapt other repertoire to and becomes its own
expressive system with its own grammar.

## Three principles

**One. Texture is the structural unit of harp arrangement.** On piano you
decide which chord, then voice it. On harp you decide which *texture* —
Alberti, walking, rolled, pedal-point — and the voicing follows. This book is
a catalogue of textures.

**Two. The harp sustains; patterns exploit that.** Almost every drill is
built around the fact that plucked strings ring for seconds. Re-striking a
chord that's already ringing produces mud, not refreshment. The patterns are
ways of keeping the chord audibly present without ever re-attacking the same
note unnecessarily.

**Three. Diatonic discipline is freeing, not limiting.** Within a single
diatonic key, the available material is dense enough for thousands of
arrangements. Constraining yourself to "no lever changes, ever" forces you
to find expression in texture rather than chromaticism. The drills here are
all strictly diatonic, and the resulting vocabulary works on any lever harp
in any key.

## The instrument

This book assumes a 33-string lever harp, range C2–A6, levers set once at
the start of a piece. If you have a pedal harp, every drill here still
applies — you just have access to range below C2 and above A6 that this book
doesn't address, plus chromatic flexibility that this book doesn't use.

## What this book is not

It is not a method book for beginners. You should already be able to pluck
each finger independently, hold a basic chord, and read music in treble and
bass clefs. If you can play Tournier's *Méthode complète* lesson 5 or
Grossi's *Method* introductory exercises, you're ready for chapter 1.

It is not a repertoire book. There are no pieces here — only the patterns
that pieces are built from.

It is not a theory book. Roman numerals appear in chord cycles, but the book
does not teach harmony. Familiarity with the diatonic triads (I, ii, iii,
IV, V, vi, vii°) of a major key is assumed.

## How to work through it

Spend a week or two on each chapter. Get every drill in a chapter to a
playable, even, musical state before moving on. Practice each drill in at
least three keys (C, G, F) and ideally all seven that the lever harp gives
you cleanly (C, G, D, A, F, B♭, E♭).

The chord-cycle expansion in chapter 10 is the bridge from drills to real
playing. Once you can run any mastered pattern through any cycle without
hesitation, you have the physical vocabulary to arrange hymns and similar
pieces freely.

That's the goal: not to play these drills, but to no longer need them.
