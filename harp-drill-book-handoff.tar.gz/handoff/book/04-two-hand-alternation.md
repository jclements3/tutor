# Chapter 4 — Two-hand alternation

These drills introduce the second hand. The discipline of this chapter is
**strict alternation** — the two hands never play at the same time, but
together they produce a continuous texture. Mastering alternation is the
prerequisite for everything in chapters 5–7.

---

## 4.1 Oom-pah (4/4)

**Hand:** two-handed
**Meter:** 4/4
**Rate:** quarter notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

LH plays bass note on beats 1 and 3. RH plays the rest of the chord
(blocked, struck together) on beats 2 and 4. Hands strictly alternate.
The classic folk/gospel/march texture.

```abc
X:1
T:4.1 Oom-pah
M:4/4
L:1/4
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] z [ceg] z [ceg] | z [fac'] z [fac'] | z [GBd] z [GBd] | z [ceg] z [ceg] |
[V:LH] "C" C, z C, z | "F" F, z F, z | "G" G,, z G,, z | "C" C, z C, z |
```

**Practice in keys:** all seven
**Mastery criterion:** LH hits beats 1 and 3 exactly; RH hits beats 2
and 4 exactly; no overlap, no syncopation, no drift over four bars.

**Common error:** the RH chord rolls instead of struck. Oom-pah uses
*blocked* chord on the offbeats — all RH notes together, no roll.

---

## 4.2 Waltz bass (3/4)

**Hand:** two-handed
**Meter:** 3/4
**Rate:** quarter notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I in 3/4

LH on beat 1 alone, RH chord on beats 2 and 3. The defining accompaniment
of waltz, ländler, mazurka. Mid-19th-century salon-piano standard.

```abc
X:1
T:4.2 Waltz bass
M:3/4
L:1/4
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] z [ceg] [ceg] | z [fac'] [fac'] | z [GBd] [GBd] | z [ceg] [ceg] |
[V:LH] "C" C, z z | "F" F, z z | "G" G,, z z | "C" C, z z |
```

**Practice in keys:** all seven
**Mastery criterion:** beat 1 has clear weight from the LH; beats 2 and
3 have lighter equal RH chords; no rushing into the new bar's beat 1.

**Common error:** beats 2 and 3 are played with different velocity. Both
RH chord strikes should be the same volume — beat 1 is the heavy one,
beats 2 and 3 are equally light.

---

## 4.3 Slow oom-pah

**Hand:** two-handed
**Meter:** 4/4
**Rate:** half notes
**Tempo target:** 60 bpm
**Cycle:** I – IV – V – I

The oom-pah pattern stretched to half-note pacing. LH on beat 1, RH chord
on beat 3. The slow pacing exposes the harp's ring — the LH note must
sustain through two full beats before the RH chord enters.

```abc
X:1
T:4.3 Slow oom-pah
M:4/4
L:1/2
K:C
%%score (RH) (LH)
V:RH clef=treble
V:LH clef=bass
[V:RH] z [ceg] | z [fac'] | z [GBd] | z [ceg] |
[V:LH] "C" C, z | "F" F, z | "G" G,, z | "C" C, z |
```

**Practice in keys:** all seven
**Mastery criterion:** the LH note is allowed to fully ring through
beats 1–2; the RH chord on beat 3 doesn't compete with or obscure the
LH's resonance.

**Common error:** re-attacking the LH bass note on beat 3 (or anytime
before beat 1 of the next bar). The LH plays *once* per bar; let it
ring.
