# Chapter 2 — Zigzag patterns

The zigzag family alternates the bass note with upper chord tones, creating
a bouncing feel between low and high registers. These are the most common
broken-chord patterns in Western keyboard and harp music. Master Alberti
(2.1) thoroughly before moving on; the rest are permutations of the same
finger motion.

---

## 2.1 Alberti — b·t·m·t

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I

The canonical zigzag. Bottom note, top, middle, top — repeated. Two cycles
of the four-note pattern fill one bar.

```abc
X:1
T:2.1 Alberti
M:4/4
L:1/8
K:C
"C" C,G,E,G, C,G,E,G, | "F" F,CA,C F,CA,C | "G" G,,DB,,D G,,DB,,D | "C" C,G,E,G, C,G,E,G, |
```

**Practice in keys:** all seven
**Mastery criterion:** smooth eighth-note flow at 90 bpm with no
fingering hesitation; equal volume on every note; the chord change at
each bar line is audible only from the new pitches, not from any
rhythmic stumble.

**Common error:** the top note (beat 1.5 of each cycle) is accented
unintentionally because it's reached with the thumb. Keep the thumb's
attack equal to the other fingers.

---

## 2.2 Murky bass — b·m·t·m

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I

Same notes as Alberti, different order. Bottom, middle, top, middle —
more uniform than Alberti because no single note bounces out as a
high marker. Found in Bach and early Haydn.

```abc
X:1
T:2.2 Murky bass
M:4/4
L:1/8
K:C
"C" C,E,G,E, C,E,G,E, | "F" F,A,cA, F,A,cA, | "G" G,,B,,DB,, G,,B,,DB,, | "C" C,E,G,E, C,E,G,E, |
```

**Practice in keys:** all seven
**Mastery criterion:** evenness across all four notes per cycle; no note
audibly louder than its neighbors.

**Common error:** falling back into the Alberti shape (b·t·m·t) when
attention drifts. Murky bass is genuinely a different pattern; the
middle note replaces the top on the "and" of beats 1 and 3.

---

## 2.3 Reverse Alberti — t·b·m·b

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I

Top note on the beat, bass on the offbeats. Same notes, flipped. The
strong beats now carry the top note, making this pattern feel gentler
than standard Alberti.

```abc
X:1
T:2.3 Reverse Alberti
M:4/4
L:1/8
K:C
"C" G,C,E,C, G,C,E,C, | "F" cF,A,F, cF,A,F, | "G" DG,,B,,G,, DG,,B,,G,, | "C" G,C,E,C, G,C,E,C, |
```

**Practice in keys:** all seven
**Mastery criterion:** the bass note on the offbeats remains audible
even though it's no longer on the beat; pattern flows smoothly.

---

## 2.4 Cascading — t·m·b·m

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – vi – IV – I (descending-feeling progression)

Mirror image of Alberti. Top, middle, bottom, middle. Falling and
returning shape; slightly melancholy character.

```abc
X:1
T:2.4 Cascading
M:4/4
L:1/8
K:C
"C" G,E,C,E, G,E,C,E, | "Am" cA,E,A, cA,E,A, | "F" cA,F,A, cA,F,A, | "C" G,E,C,E, G,E,C,E, |
```

**Practice in keys:** all seven
**Mastery criterion:** the descending shape doesn't accelerate; the
falling motion stays controlled.

**Common error:** the top note is rushed because the natural hand motion
wants to release from a high finger faster. Keep the top note's
duration equal to the other notes.

---

## 2.5 Inner-bounce — m·t·m·b

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 90 bpm
**Cycle:** I – IV – V – I

The middle note carries the beat; the bass appears only on the "and" of
beats 2 and 4. Bass is the *sparsest* of any zigzag — used when you
want a chord present without a strong bass thump.

```abc
X:1
T:2.5 Inner-bounce
M:4/4
L:1/8
K:C
"C" E,G,E,C, E,G,E,C, | "F" A,cA,F, A,cA,F, | "G" B,,DB,,G,, B,,DB,,G,, | "C" E,G,E,C, E,G,E,C, |
```

**Practice in keys:** all seven
**Mastery criterion:** the bass note, though sparse, remains clearly
audible; the middle note's beat-emphasis doesn't drown out the bass.

---

## 2.6 Pattern switching within a phrase

**Hand:** LH alone
**Meter:** 4/4
**Rate:** eighth notes
**Tempo target:** 80 bpm
**Cycle:** I – IV – V – I

The composition exercise. Bar 1 = Alberti, bar 2 = Murky bass, bar 3 =
Cascading, bar 4 = Reverse Alberti. Same chord progression, four
different zigzag patterns. Trains the ability to switch patterns at
phrase boundaries.

```abc
X:1
T:2.6 Pattern switching
M:4/4
L:1/8
K:C
"C" C,G,E,G, C,G,E,G, | "F" F,A,cA, F,A,cA, | "G" DB,,G,,B,, DB,,G,,B,, | "C" G,C,E,C, G,C,E,C, |
```

**Practice in keys:** C, G, F
**Mastery criterion:** each pattern is clean within its bar; the
transitions at bar lines don't introduce hesitation or wrong notes.

**Common error:** the pattern from the previous bar bleeds into the new
bar (e.g., Alberti's b·t·m·t pattern starts the new bar instead of
Murky's b·m·t·m). Practice the bar transitions slowly until each
pattern's first note is automatic.
