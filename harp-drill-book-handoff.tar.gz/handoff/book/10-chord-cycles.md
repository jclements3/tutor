# Chapter 10 — Chord-cycle expansion

Once any pattern from chapters 1–7 is mastered through the basic I – IV – V – I
cycle, the next step is fluency: applying that pattern to *any* diatonic chord
progression without hesitation. This chapter provides six progressions to drill
mastered patterns through.

The principle: pick any mastered pattern (Alberti from 2.1, Waltz bass from
4.2, Pedal + Alberti from 6.3, etc.) and run it through every cycle below.
By the time you've done this for several patterns, the *family* of patterns
is internalized — the cycle itself recedes and the pattern's physical shape
becomes the focus.

Each cycle is given here in the abstract (roman numerals) and as a concrete
realization in C major. Practice in all seven lever-harp keys for full
fluency.

---

## 10.1 Cadential — I – IV – V – I

The basic four-bar cadential phrase. Every drill in chapters 1–7 uses this.

**Roman numerals:** I – IV – V – I
**In C:** C – F – G – C
**In G:** G – C – D – G
**In F:** F – B♭ – C – F

```abc
X:1
T:10.1 Cadential cycle
M:4/4
L:1/4
K:C
"C" C4 | "F" F4 | "G" G,4 | "C" C4 |
```

---

## 10.2 Folk loop — I – vi – IV – V

The pop and folk vamp. Two bars of "home" feeling (I, vi), then
preparation (IV, V) that drives back to I. Endlessly repeatable.

**Roman numerals:** I – vi – IV – V – (back to I or repeat)
**In C:** C – Am – F – G
**In G:** G – Em – C – D

```abc
X:1
T:10.2 Folk loop
M:4/4
L:1/4
K:C
"C" C4 | "Am" A,4 | "F" F4 | "G" G,4 |
```

---

## 10.3 Inverted folk — vi – IV – I – V

The same chords as 10.2 in a different order. Modern pop's most common
progression (the "axis of awesome"). Starts on vi (minor) for a more
contemplative or melancholy character.

**Roman numerals:** vi – IV – I – V
**In C:** Am – F – C – G

```abc
X:1
T:10.3 Inverted folk
M:4/4
L:1/4
K:C
"Am" A,4 | "F" F4 | "C" C4 | "G" G,4 |
```

---

## 10.4 Pachelbel — I – V – vi – iii – IV – I – IV – V

The eight-bar circle-of-fifths-within-diatonic progression. Pachelbel's
Canon. Each chord moves down by a 4th (root motion: C → G → A → E → F →
C → F → G). Forms a strong directed harmonic momentum.

**Roman numerals:** I – V – vi – iii – IV – I – IV – V
**In C:** C – G – Am – Em – F – C – F – G

```abc
X:1
T:10.4 Pachelbel
M:4/4
L:1/4
K:C
"C" C4 | "G" G,4 | "Am" A,4 | "Em" E4 | "F" F4 | "C" C4 | "F" F4 | "G" G,4 |
```

---

## 10.5 Jazz turnaround — ii – V – I (diatonic)

The most common diatonic turnaround in jazz. Diatonic-only here (no
secondary dominants, no tritone subs), so it stays within the
no-flips rule of this book.

**Roman numerals:** ii – V – I (often repeated, or extended to ii – V – I – vi)
**In C:** Dm – G – C – (back to Dm or extend with Am)

```abc
X:1
T:10.5 Jazz turnaround (diatonic)
M:4/4
L:1/4
K:C
"Dm" D4 | "G" G,4 | "C" C4 | "C" C4 |
```

---

## 10.6 Full diatonic walk — I – ii – iii – IV – V – vi – vii° – I

Every diatonic triad in scale order. Eight bars, one chord per bar. The
hardest cycle in the book because every chord must be playable on
demand — including the awkward iii and vii° that don't appear in the
other cycles.

**Roman numerals:** I – ii – iii – IV – V – vi – vii° – I
**In C:** C – Dm – Em – F – G – Am – B°(dim) – C

```abc
X:1
T:10.6 Full diatonic walk
M:4/4
L:1/4
K:C
"C" C4 | "Dm" D4 | "Em" E4 | "F" F4 | "G" G,4 | "Am" A,4 | "Bdim" B,4 | "C" C4 |
```

**Mastery criterion for this cycle:** every chord, including iii and
vii°, has a clean voicing in the hand without hesitation. The
diminished triad vii° (B-D-F in C major) is the awkward one — the
diminished 5th makes it hard to "feel" as a stable harmony, but on
the harp it's just another set of strings.

---

## Practice routine using chapter 10

For each pattern in chapters 1–7 that you've mastered:

1. Play the pattern through cycle 10.1 (the basic cadential).
2. Then play the same pattern through cycle 10.2 (folk loop).
3. Continue through cycles 10.3 through 10.6.
4. Now switch keys: play the pattern through *all six cycles* in
   the new key.
5. Continue until you've covered all seven lever-harp keys.

Total: 7 patterns × 6 cycles × 7 keys = **294 mini-drills**, but
each one takes maybe 30 seconds. The full chord-cycle expansion
might take 2–3 weeks of regular practice to internalize, but it's
the bridge from "knowing the patterns" to "fluent in the patterns."

Once you can do this, you can read any diatonic hymn and choose any
pattern from the book without thinking about whether it'll work —
because you've drilled every pattern through every common chord
arrangement.

---

## A note on minor-key hymns

The cycles above assume major-key diatonic. For minor-key hymns,
substitute the natural-minor diatonic chords:

**Minor-key diatonic triads (A minor as example):**
i (Am), ii° (B°), III (C), iv (Dm), v (Em) or V (E major, with raised
7th), VI (F), VII (G)

The lever harp's no-flips rule means *natural minor* throughout — the V
chord is *minor* (e.g., Em in A minor), not the harmonic-minor major V
that classical practice prefers. This gives minor-key hymns a slightly
modal, folk-like character. This is a feature, not a limitation.

Adapt the cycles above to minor by substituting the minor-key
equivalents. The pattern shapes are unchanged.
