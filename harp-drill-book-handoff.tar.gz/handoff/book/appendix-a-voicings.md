# Appendix A — Chord voicings on the lever harp

Every drill in this book uses three-note triads (root, third, fifth). For
the LH-alone drills, the triad sits with its bass note in octave 2 or 3.
For two-hand drills, the LH plays the bass note in octave 2 and the RH
plays an upper-register voicing.

This appendix shows the standard voicings for each diatonic triad in each
of the seven lever-harp keys. The voicings prioritize *hand position over
correctness* — pick the voicing that lies under the hand naturally.

---

## C major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (C) | C2 E2 G2 | C4 E4 G4 |
| ii (Dm) | D2 F2 A2 | D4 F4 A4 |
| iii (Em) | E2 G2 B2 | E4 G4 B4 |
| IV (F) | F2 A2 C3 | F4 A4 C5 |
| V (G) | G2 B2 D3 | G4 B4 D5 |
| vi (Am) | A2 C3 E3 | A4 C5 E5 |
| vii° (B°) | B2 D3 F3 | B4 D5 F5 |

---

## G major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (G) | G2 B2 D3 | G4 B4 D5 |
| ii (Am) | A2 C3 E3 | A4 C5 E5 |
| iii (Bm) | B2 D3 F♯3 | B4 D5 F♯5 |
| IV (C) | C3 E3 G3 | C5 E5 G5 |
| V (D) | D3 F♯3 A3 | D5 F♯5 A5 |
| vi (Em) | E2 G2 B2 | E4 G4 B4 |
| vii° (F♯°) | F♯3 A3 C4 | F♯5 A5 C6 |

---

## D major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (D) | D2 F♯2 A2 | D4 F♯4 A4 |
| ii (Em) | E2 G2 B2 | E4 G4 B4 |
| iii (F♯m) | F♯2 A2 C♯3 | F♯4 A4 C♯5 |
| IV (G) | G2 B2 D3 | G4 B4 D5 |
| V (A) | A2 C♯3 E3 | A4 C♯5 E5 |
| vi (Bm) | B2 D3 F♯3 | B4 D5 F♯5 |
| vii° (C♯°) | C♯3 E3 G3 | C♯5 E5 G5 |

---

## A major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (A) | A2 C♯3 E3 | A4 C♯5 E5 |
| ii (Bm) | B2 D3 F♯3 | B4 D5 F♯5 |
| iii (C♯m) | C♯3 E3 G♯3 | C♯5 E5 G♯5 |
| IV (D) | D3 F♯3 A3 | D5 F♯5 A5 |
| V (E) | E2 G♯2 B2 | E4 G♯4 B4 |
| vi (F♯m) | F♯2 A2 C♯3 | F♯4 A4 C♯5 |
| vii° (G♯°) | G♯2 B2 D3 | G♯4 B4 D5 |

---

## F major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (F) | F2 A2 C3 | F4 A4 C5 |
| ii (Gm) | G2 B♭2 D3 | G4 B♭4 D5 |
| iii (Am) | A2 C3 E3 | A4 C5 E5 |
| IV (B♭) | B♭2 D3 F3 | B♭4 D5 F5 |
| V (C) | C3 E3 G3 | C5 E5 G5 |
| vi (Dm) | D2 F2 A2 | D4 F4 A4 |
| vii° (E°) | E2 G2 B♭2 | E4 G4 B♭4 |

---

## B♭ major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (B♭) | B♭2 D3 F3 | B♭4 D5 F5 |
| ii (Cm) | C3 E♭3 G3 | C5 E♭5 G5 |
| iii (Dm) | D2 F2 A2 | D4 F4 A4 |
| IV (E♭) | E♭2 G2 B♭2 | E♭4 G4 B♭4 |
| V (F) | F2 A2 C3 | F4 A4 C5 |
| vi (Gm) | G2 B♭2 D3 | G4 B♭4 D5 |
| vii° (A°) | A2 C3 E♭3 | A4 C5 E♭5 |

---

## E♭ major key

|Chord | LH voicing (bass) | RH voicing (treble) |
|------|-------------------|---------------------|
| I (E♭) | E♭2 G2 B♭2 | E♭4 G4 B♭4 |
| ii (Fm) | F2 A♭2 C3 | F4 A♭4 C5 |
| iii (Gm) | G2 B♭2 D3 | G4 B♭4 D5 |
| IV (A♭) | A♭2 C3 E♭3 | A♭4 C5 E♭5 |
| V (B♭) | B♭2 D3 F3 | B♭4 D5 F5 |
| vi (Cm) | C3 E♭3 G3 | C5 E♭5 G5 |
| vii° (D°) | D2 F2 A♭2 | D4 F4 A♭4 |

---

## Notes on voicing choice

The voicings listed are *standard* but not the only option. Two principles
to deviate by:

**Reach.** If a voicing puts the top note out of comfortable reach for the
hand, drop it down an octave. This is especially relevant for vii° chords
where the diminished 5th might be uncomfortable.

**Voice-leading.** When moving between two chords, prefer voicings that
share notes or move by step. For example, going from I to IV in C major,
C-E-G → C-F-A keeps C in place and moves E up to F (a step) and G up to
A (a step). All notes move stepwise. This sounds smoother than
C-E-G → F-A-C.

For the drills in this book, the standard voicings above work everywhere.
Voice-leading optimization is a refinement that comes later, with
experience.
