"""
Build the harp drill book as a single self-contained HTML file (and PDF).

Usage:
    python3 build_book.py                       # builds HTML + PDF in current dir
    python3 build_book.py --html-only           # skip PDF (no wkhtmltopdf needed)
    python3 build_book.py --book-dir ./book     # custom source directory

Requires:
    - abcm2ps  (apt-get install abcm2ps)
    - wkhtmltopdf for PDF output (apt-get install wkhtmltopdf)
"""

import argparse
import os
import re
import subprocess

CHAPTER_FILES = [
    'README.md',
    '00-preface.md',
    '00-notation.md',
    '01-single-hand-foundations.md',
    '02-zigzag-patterns.md',
    '03-linear-arpeggios.md',
    '04-two-hand-alternation.md',
    '05-block-and-rolled.md',
    '06-layered-textures.md',
    '07-wide-spread.md',
    '08-modifiers.md',
    '09-gestures.md',
    '10-chord-cycles.md',
    'appendix-a-voicings.md',
    'appendix-b-keys.md',
    'appendix-c-routine.md',
    'appendix-d-index.md',
]


def render_abc_to_svg(abc_code, out_basename, work_dir):
    abc_path = os.path.join(work_dir, out_basename + '.abc')
    with open(abc_path, 'w') as f:
        f.write(abc_code)
    svg_path = os.path.join(work_dir, out_basename + '.svg')
    subprocess.run(
        ['abcm2ps', '-g', '-O', svg_path, '-w', '17cm', abc_path],
        capture_output=True, text=True
    )
    for candidate in [svg_path, svg_path.replace('.svg', '001.svg')]:
        if os.path.exists(candidate):
            with open(candidate) as f:
                svg = f.read()
            svg = re.sub(r'<\?xml[^>]*\?>\s*', '', svg)
            svg = re.sub(r'<!DOCTYPE[^>]*>\s*', '', svg)
            # collapse to one line and strip fixed dimensions
            svg = re.sub(r'\s+', ' ', svg).strip()
            svg = re.sub(r'\s+width="[^"]*"', '', svg, count=1)
            svg = re.sub(r'\s+height="[^"]*"', '', svg, count=1)
            return svg
    return None


def md_to_html(text):
    lines = text.split('\n')
    out = []
    in_para = False
    in_list = None
    in_table = False

    def close_para():
        nonlocal in_para
        if in_para: out.append('</p>'); in_para = False

    def close_list():
        nonlocal in_list
        if in_list: out.append(f'</{in_list}>'); in_list = None

    def close_table():
        nonlocal in_table
        if in_table: out.append('</table>'); in_table = False

    def inline(s):
        s = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
        s = re.sub(r'(?<!\*)\*([^\*\n]+)\*(?!\*)', r'<em>\1</em>', s)
        s = re.sub(r'`([^`]+)`', r'<code>\1</code>', s)
        return s

    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith('<div class="staff">'):
            close_para(); close_list(); close_table()
            out.append(line); i += 1; continue
        if line.startswith('# '):
            close_para(); close_list(); close_table()
            out.append(f'<h1>{inline(line[2:])}</h1>'); i += 1; continue
        if line.startswith('## '):
            close_para(); close_list(); close_table()
            out.append(f'<h2>{inline(line[3:])}</h2>'); i += 1; continue
        if line.startswith('### '):
            close_para(); close_list(); close_table()
            out.append(f'<h3>{inline(line[4:])}</h3>'); i += 1; continue
        if line.startswith('---') and line.strip() == '---':
            close_para(); close_list(); close_table()
            out.append('<hr>'); i += 1; continue
        if line.startswith('|') and i + 1 < len(lines) and re.match(r'^\|[\s\-|:]+\|', lines[i+1]):
            close_para(); close_list()
            if not in_table:
                out.append('<table>'); in_table = True
            cells = [c.strip() for c in line.strip('|').split('|')]
            out.append('<thead><tr>' + ''.join(f'<th>{inline(c)}</th>' for c in cells) + '</tr></thead>')
            i += 2
            out.append('<tbody>')
            while i < len(lines) and lines[i].startswith('|'):
                cells = [c.strip() for c in lines[i].strip('|').split('|')]
                out.append('<tr>' + ''.join(f'<td>{inline(c)}</td>' for c in cells) + '</tr>')
                i += 1
            out.append('</tbody>')
            close_table(); continue
        if re.match(r'^[\-\*]\s+', line):
            close_para(); close_table()
            if in_list != 'ul':
                close_list(); out.append('<ul>'); in_list = 'ul'
            content = re.sub(r'^[\-\*]\s+', '', line)
            out.append(f'<li>{inline(content)}</li>'); i += 1; continue
        if re.match(r'^\d+\.\s+', line):
            close_para(); close_table()
            if in_list != 'ol':
                close_list(); out.append('<ol>'); in_list = 'ol'
            content = re.sub(r'^\d+\.\s+', '', line)
            out.append(f'<li>{inline(content)}</li>'); i += 1; continue
        if line.startswith('> '):
            close_para(); close_list(); close_table()
            out.append(f'<blockquote>{inline(line[2:])}</blockquote>'); i += 1; continue
        if line.strip() == '':
            close_para(); close_list(); i += 1; continue
        close_list(); close_table()
        if not in_para:
            out.append('<p>'); in_para = True
        out.append(inline(line))
        i += 1

    close_para(); close_list(); close_table()
    return '\n'.join(out)


CSS = """
<style>
  body {
    font-family: Georgia, 'Times New Roman', serif;
    max-width: 20cm; margin: 2cm auto; line-height: 1.55;
    color: #222; padding: 0 1em;
  }
  h1 {
    font-size: 22pt; border-bottom: 2px solid #444;
    padding-bottom: 0.2em; margin-top: 2em; page-break-before: always;
  }
  h1:first-of-type { page-break-before: avoid; margin-top: 0; }
  h2 {
    font-size: 16pt; margin-top: 2em; color: #555;
    border-bottom: 1px solid #ddd; padding-bottom: 0.2em;
  }
  h3 { font-size: 13pt; color: #666; margin-top: 1.5em; }
  p, li, td, th { font-size: 11pt; }
  strong { color: #333; }
  em { color: #444; }
  .staff { margin: 1em 0; page-break-inside: avoid; overflow-x: auto; }
  .staff svg { display: block; width: 100%; height: auto; max-width: 100%; }
  hr { border: none; border-top: 1px solid #ccc; margin: 2em 0; }
  table { border-collapse: collapse; width: 100%; margin: 1em 0; font-size: 10pt; }
  th, td { border: 1px solid #ccc; padding: 0.4em 0.7em; text-align: left; }
  th { background: #f5f5f5; font-weight: bold; }
  blockquote {
    border-left: 3px solid #aaa; margin-left: 0; padding-left: 1em;
    color: #555; font-style: italic;
  }
  code {
    font-family: 'DejaVu Sans Mono', Consolas, monospace;
    background: #f5f5f5; padding: 0.1em 0.3em; border-radius: 3px;
    font-size: 0.95em;
  }
  ul, ol { margin: 0.5em 0 1em 1.5em; }
  li { margin: 0.2em 0; }
  .chapter-separator { border: none; border-top: 3px double #888; margin: 3em 0; }
</style>
"""


def build(book_dir, out_html, html_only=False, out_pdf=None):
    work_dir = os.path.join(os.path.dirname(out_html) or '.', '_render_work')
    os.makedirs(work_dir, exist_ok=True)

    abc_pattern = re.compile(r'```abc\n(.*?)\n```', re.DOTALL)
    processed_chapters = []
    total_abc = 0
    total_rendered = 0

    for chapter_file in CHAPTER_FILES:
        path = os.path.join(book_dir, chapter_file)
        if not os.path.exists(path):
            print(f"  skip (missing): {chapter_file}")
            continue
        with open(path) as f:
            md = f.read()
        abc_blocks = abc_pattern.findall(md)
        total_abc += len(abc_blocks)
        for i, abc_code in enumerate(abc_blocks, 1):
            key = chapter_file.replace('.md', '').replace('-', '_')
            svg = render_abc_to_svg(abc_code, f"{key}_drill_{i}", work_dir)
            if svg:
                total_rendered += 1
                block = '```abc\n' + abc_code + '\n```'
                md = md.replace(block, f'<div class="staff">{svg}</div>', 1)
            else:
                print(f"  FAILED: {chapter_file} block {i}")
        processed_chapters.append((chapter_file, md))

    print(f"Rendered {total_rendered}/{total_abc} ABC blocks")

    body_parts = []
    for _, md in processed_chapters:
        body_parts.append(md_to_html(md))
        body_parts.append('<hr class="chapter-separator">')
    if body_parts and body_parts[-1] == '<hr class="chapter-separator">':
        body_parts.pop()

    html = (
        '<!DOCTYPE html>\n<html lang="en">\n<head>\n'
        '<meta charset="utf-8">\n<title>Harp Drill Book</title>\n'
        f'{CSS}\n</head>\n<body>\n'
        + '\n'.join(body_parts)
        + '\n</body>\n</html>\n'
    )
    with open(out_html, 'w') as f:
        f.write(html)
    print(f"Wrote {out_html} ({os.path.getsize(out_html)/1024:.1f} KB)")

    if html_only:
        return

    if out_pdf is None:
        out_pdf = out_html.rsplit('.', 1)[0] + '.pdf'

    result = subprocess.run([
        'wkhtmltopdf', '--enable-local-file-access',
        '--page-size', 'A4',
        '--margin-top', '15mm', '--margin-bottom', '15mm',
        '--margin-left', '12mm', '--margin-right', '12mm',
        out_html, out_pdf
    ], capture_output=True, text=True)
    if result.returncode == 0:
        print(f"Wrote {out_pdf} ({os.path.getsize(out_pdf)/1024:.1f} KB)")
    else:
        print(f"PDF failed (HTML still produced): {result.stderr[:300]}")


if __name__ == '__main__':
    here = os.path.dirname(os.path.abspath(__file__))
    parser = argparse.ArgumentParser()
    parser.add_argument('--book-dir', default=os.path.join(here, 'book'))
    parser.add_argument('--out', default=os.path.join(here, 'harp-drill-book.html'))
    parser.add_argument('--html-only', action='store_true')
    args = parser.parse_args()
    build(args.book_dir, args.out, html_only=args.html_only)
